"""Local-file checks and the two-step Rally upload (content, then attachment record)."""
from __future__ import annotations

import base64
import hashlib
import mimetypes
import os


class AttachmentError(Exception):
    pass


def check_file(path: str, max_bytes: int) -> dict:
    """Validate a local file. Returns {path, name, size, mime, sha256} or raises AttachmentError."""
    p = os.path.expanduser(path)
    if not os.path.isfile(p):
        raise AttachmentError("file not found")
    size = os.path.getsize(p)
    if size == 0:
        raise AttachmentError("file is empty")
    if size > max_bytes:
        raise AttachmentError(f"file is {size // 1024} KB; limit is {max_bytes // 1024} KB "
                              "(raise attachments.max_mb if Rally allows more)")
    try:
        with open(p, "rb") as fh:
            data = fh.read()
    except OSError as e:
        raise AttachmentError(f"cannot read file: {e.strerror or e}")
    name = os.path.basename(p)
    return {"path": os.path.abspath(p), "name": name, "size": size,
            "mime": mimetypes.guess_type(name)[0] or "application/octet-stream",
            "sha256": hashlib.sha256(data).hexdigest()}


def upload(client, artifact_ref: str, info: dict, max_bytes: int) -> None:
    """Upload one checked file and link it to the artifact. Re-checks the file to catch changes."""
    fresh = check_file(info["path"], max_bytes)
    if info.get("sha256") and fresh["sha256"] != info["sha256"]:
        raise AttachmentError("file changed since it was approved")
    with open(fresh["path"], "rb") as fh:
        b64 = base64.b64encode(fh.read()).decode("ascii")
    content_ref = client.create_attachment_content(b64)
    client.create_attachment(artifact_ref, content_ref, fresh["name"], fresh["mime"], fresh["size"])
