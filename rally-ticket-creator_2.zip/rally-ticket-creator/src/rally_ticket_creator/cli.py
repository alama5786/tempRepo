"""Command line entry point.

  rally-ticket-creator check
  rally-ticket-creator plan   (--json FILE | --title T --description D [...]) [--out FILE]
  rally-ticket-creator create --plan FILE --approve DIGEST [--allow-duplicate N ...]
  rally-ticket-creator create (--json FILE | --title ...)     # only when approvals.required is false

Exit codes: 0 ok | 1 something failed/invalid | 2 setup, config or approval error |
            3 a decision is needed (type undecided, possible duplicate)
"""
from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .approvals import (ApprovalError, build_plan, load_plan, render_preview, save_plan,
                        select_for_creation, verify_approval)
from .attachments import AttachmentError, check_file, upload
from .config import Config, ConfigError, api_key, load_config
from .duplicates import find_batch_duplicates, find_duplicates
from .rally_api import RallyClient, RallyError
from .validation import TYPES, ValidationError, normalize, resolve_priority

DEFAULT_PLAN = ".rally-plan.json"
EXIT_OK, EXIT_FAILED, EXIT_SETUP, EXIT_DECISION = 0, 1, 2, 3


# ----------------------------------------------------------------- input
def add_input_args(sp: argparse.ArgumentParser) -> None:
    sp.add_argument("--json", help="JSON file with one or many tickets ('-' for stdin)")
    sp.add_argument("--title")
    sp.add_argument("--description")
    sp.add_argument("--type")
    sp.add_argument("--priority")
    sp.add_argument("--project")
    sp.add_argument("--attach", action="append", default=[])


def load_requests(args: argparse.Namespace) -> list:
    if args.json:
        try:
            src = sys.stdin.read() if args.json == "-" else open(args.json, encoding="utf-8-sig").read()
            data = json.loads(src)
        except (OSError, ValueError) as e:
            raise ConfigError(f"Cannot read ticket JSON: {e}")
        if isinstance(data, dict) and "tickets" in data:
            data = data["tickets"]
        return data if isinstance(data, list) else [data]
    if not (args.title or args.description):
        raise ConfigError("Provide --json FILE or --title and --description.")
    return [{"title": args.title, "description": args.description, "type": args.type,
             "priority": args.priority, "project": args.project, "attachments": args.attach}]


# -------------------------------------------------------------- pipeline
def prepare_items(client: RallyClient, cfg: Config, raw_list: list) -> list:
    """Validate, resolve priority and project, check files, and look for duplicates."""
    client.context()  # fail fast (auth/profile problems abort the run instead of failing every ticket)
    items = []
    for i, raw in enumerate(raw_list, 1):
        t, errs = normalize(raw, i, cfg.type_keywords)
        item = {"index": i, "status": "ready", "title": (t or {}).get("title", ""),
                "description": (t or {}).get("description", ""), "type": (t or {}).get("type"),
                "type_inferred": (t or {}).get("type_inferred", False), "priority": None,
                "priority_note": None, "project": (t or {}).get("project"), "project_name": None,
                "attachments": [], "attachment_errors": [], "duplicates": [], "notes": [], "errors": errs}
        items.append(item)
        if errs:
            item["status"] = "invalid"
            continue
        if item["type"] is None:
            item["status"] = "needs_type"
            continue
        try:
            item["project_name"] = client.context(item["project"])["project"]["name"]
            prio, note = resolve_priority(client.allowed_values(item["type"]), t["priority_requested"],
                                          cfg.priority_synonyms, cfg.default_priority)
            item["priority"], item["priority_note"] = prio, note
        except (ValidationError, RallyError) as e:
            item["status"], item["errors"] = "invalid", [str(e)]
            continue
        for p in t["attachment_paths"]:
            try:
                item["attachments"].append(check_file(p, cfg.max_attachment_bytes))
            except AttachmentError as e:
                item["attachment_errors"].append(f"{p}: {e}")

    live = [i for i in items if i["status"] == "ready"]
    if cfg.duplicates_enabled and live:
        for it in live:
            try:
                it["duplicates"] = find_duplicates(client, it, cfg)
            except RallyError as e:
                it["notes"].append(f"duplicate check failed: {e}")
        batch = find_batch_duplicates(live, cfg.duplicates_threshold)
        for it in live:
            it["duplicates"] += batch.get(it["index"], [])
            if it["duplicates"]:
                it["status"] = "possible_duplicate"
    return items


def execute(client: RallyClient, cfg: Config, plan: dict, plan_path: str | None, allow_dups: set) -> int:
    to_create, skipped = select_for_creation(plan, allow_dups)
    results, failed, undecided = [], False, False
    for item, reason in skipped:
        if item.get("created"):
            print(f"SKIP  #{item['index']} {item['title']}: {reason}")
            continue
        if item["status"] in ("possible_duplicate", "needs_type"):
            undecided = True
        else:
            failed = True
        print(f"SKIP  #{item['index']} {item['title'] or '(no title)'}: {reason}")
        results.append({"index": item["index"], "status": "skipped", "reason": reason})

    for item in to_create:
        try:
            made = client.create_ticket(item)
        except RallyError as e:
            failed = True
            print(f"FAIL  #{item['index']} {item['title']}: {e}")
            results.append({"index": item["index"], "status": "failed", "error": str(e)})
            continue
        item["created"] = {"id": made["id"], "link": made["link"]}
        if plan_path:
            save_plan(plan, plan_path)  # a rerun of this plan will not create it twice
        att_fail = []
        for a in item["attachments"]:
            try:
                upload(client, made["ref"], a, cfg.max_attachment_bytes)
            except (AttachmentError, RallyError) as e:
                att_fail.append({"file": a["name"], "error": str(e)})
        tag = " (type inferred)" if item["type_inferred"] else ""
        print(f"OK  {made['id']}  {made['type']}{tag}  {item['title']}")
        print(f"    priority: {made['priority'] or 'unset'}  project: {made['project']}")
        print(f"    {made['link']}")
        if item["attachments"]:
            print(f"    attachments: {len(item['attachments']) - len(att_fail)}/{len(item['attachments'])} uploaded")
        for f in att_fail:
            print(f"    ! attachment failed: {f['file']}: {f['error']}")
        results.append({"index": item["index"], "status": "created", "id": made["id"],
                        "link": made["link"], "attachment_failures": att_fail})
    print("RESULT_JSON: " + json.dumps(results))
    return EXIT_FAILED if failed else (EXIT_DECISION if undecided else EXIT_OK)


# -------------------------------------------------------------- commands
def cmd_check(cfg: Config, args: argparse.Namespace) -> int:
    client = RallyClient(cfg, api_key())
    ctx = client.context()
    print(f"OK  workspace: {ctx['workspace']['name']}  project: {ctx['project']['name']}")
    for k, info in TYPES.items():
        vals = client.allowed_values(k)
        print(f"    {info['label']} priorities: {', '.join(vals) if vals else '(no Priority field)'}")
    dup = f"on (threshold {cfg.duplicates_threshold})" if cfg.duplicates_enabled else "off"
    print(f"    duplicate check: {dup}")
    print(f"    approvals: {'required (plan, then create --approve)' if cfg.approval_required else 'not required'}")
    return EXIT_OK


def cmd_plan(cfg: Config, args: argparse.Namespace) -> int:
    raw_list = load_requests(args)
    if not raw_list:
        raise ConfigError("No tickets supplied.")
    client = RallyClient(cfg, api_key())
    plan = build_plan(prepare_items(client, cfg, raw_list))
    save_plan(plan, args.out)
    print(render_preview(plan, args.out))
    statuses = {i["status"] for i in plan["items"]}
    if "invalid" in statuses:
        return EXIT_FAILED
    return EXIT_DECISION if statuses & {"needs_type", "possible_duplicate"} else EXIT_OK


def cmd_create(cfg: Config, args: argparse.Namespace) -> int:
    allow = set(args.allow_duplicate)
    if args.plan:
        plan = load_plan(args.plan)
        if cfg.approval_required:
            verify_approval(plan, args.approve)
        return execute(RallyClient(cfg, api_key()), cfg, plan, args.plan, allow)
    if cfg.approval_required:
        raise ApprovalError("Approvals are required: run `plan`, show it to the user, then "
                            "`create --plan FILE --approve DIGEST`.")
    client = RallyClient(cfg, api_key())
    plan = build_plan(prepare_items(client, cfg, load_requests(args)))
    return execute(client, cfg, plan, None, allow)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="rally-ticket-creator", description="Create Rally tickets via the WSAPI.")
    p.add_argument("--config", help="path to rally.yaml (default: config/rally.yaml)")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("check", help="verify auth and show workspace, project, priorities")
    sp = sub.add_parser("plan", help="validate and preview; creates nothing")
    add_input_args(sp)
    sp.add_argument("--out", default=DEFAULT_PLAN)
    sc = sub.add_parser("create", help="create tickets from an approved plan")
    add_input_args(sc)
    sc.add_argument("--plan", help="plan file written by `plan`")
    sc.add_argument("--approve", help="digest printed by `plan` after the user agreed")
    sc.add_argument("--allow-duplicate", type=int, action="append", default=[], metavar="N",
                    help="create item N even though it looks like a duplicate")
    return p


def main(argv: list | None = None) -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = build_parser().parse_args(argv)
    try:
        cfg = load_config(args.config)
        return {"check": cmd_check, "plan": cmd_plan, "create": cmd_create}[args.command](cfg, args)
    except (ConfigError, RallyError, ApprovalError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return EXIT_SETUP


if __name__ == "__main__":
    sys.exit(main())
