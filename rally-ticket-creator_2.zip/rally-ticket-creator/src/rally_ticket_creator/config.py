"""Configuration: defaults < config/rally.yaml < environment variables.

The API key is the one thing that never lives in a file: it is read only from
the RALLY_API_KEY environment variable.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping, Optional

ENV_KEY = "RALLY_API_KEY"
ENV_CONFIG = "RALLY_TICKET_CONFIG"

_HIGH = ["Resolve Immediately", "Critical", "Urgent"]
DEFAULT_PRIORITY_SYNONYMS = {
    "critical": _HIGH, "urgent": _HIGH, "blocker": _HIGH, "p1": _HIGH, "highest": _HIGH,
    "high": ["High Attention", "High"], "p2": ["High Attention", "High"],
    "medium": ["Normal", "Medium"], "normal": ["Normal", "Medium"], "p3": ["Normal", "Medium"],
    "low": ["Low"], "p4": ["Low"], "lowest": ["Low"],
}
DEFAULT_TYPE_KEYWORDS = {
    "defect": ["bug", "defect", "broken", "break", "breaks", "crash", "crashes", "crashed",
               "crashing", "error", "exception", "fail", "fails", "failing", "failure",
               "regression", "incorrect", "wrong", "not working", "doesn't work", "doesnt work",
               "cannot", "can't", "outage", "hang", "hangs", "hanging", "timeout", "timeouts",
               "stuck"],
    "story": ["add", "allow", "enable", "support", "as a", "i want", "so that", "new feature",
              "feature", "enhancement", "improve", "implement", "create", "introduce", "backlog"],
}


class ConfigError(Exception):
    pass


@dataclass
class Config:
    base_url: str = "https://rally1.rallydev.com"
    workspace: str = ""          # blank = default workspace on the user's Rally profile
    project: str = ""            # blank = default project on the user's Rally profile
    default_priority: str = "Normal"
    priority_synonyms: dict = field(default_factory=lambda: dict(DEFAULT_PRIORITY_SYNONYMS))
    type_keywords: dict = field(default_factory=lambda: {k: list(v) for k, v in DEFAULT_TYPE_KEYWORDS.items()})
    max_attachment_mb: float = 5
    duplicates_enabled: bool = True
    duplicates_threshold: float = 0.75
    duplicates_lookback: int = 200
    approval_required: bool = True

    @property
    def max_attachment_bytes(self) -> int:
        return int(self.max_attachment_mb * 1024 * 1024)


def api_key(env: Optional[Mapping[str, str]] = None) -> str:
    env = os.environ if env is None else env
    key = (env.get(ENV_KEY) or "").strip()
    if not key:
        raise ConfigError(
            f"{ENV_KEY} is not set. Create a Rally API key and export it as {ENV_KEY} "
            "(see README.md), then restart the terminal / Claude Code.")
    return key


def find_config_path(explicit: Optional[str] = None, env: Optional[Mapping[str, str]] = None) -> Optional[Path]:
    env = os.environ if env is None else env
    if explicit:
        p = Path(explicit).expanduser()
        if not p.is_file():
            raise ConfigError(f"Config file not found: {p}")
        return p
    if env.get(ENV_CONFIG):
        p = Path(env[ENV_CONFIG]).expanduser()
        if not p.is_file():
            raise ConfigError(f"{ENV_CONFIG} points to a missing file: {p}")
        return p
    for candidate in (Path.cwd() / "config" / "rally.yaml",
                      Path(__file__).resolve().parents[2] / "config" / "rally.yaml"):
        if candidate.is_file():
            return candidate
    return None


def _read_yaml(path: Path) -> dict:
    try:
        import yaml
    except ImportError:
        raise ConfigError("PyYAML is required to read the config file: pip install pyyaml")
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as e:
        raise ConfigError(f"Cannot parse {path}: {e}")
    if not isinstance(data, dict):
        raise ConfigError(f"{path} must contain a YAML mapping at the top level.")
    return data


def load_config(path: Optional[str] = None, env: Optional[Mapping[str, str]] = None) -> Config:
    env = os.environ if env is None else env
    cfg = Config()
    found = find_config_path(path, env)
    data = _read_yaml(found) if found else {}

    rally = data.get("rally") or {}
    cfg.base_url = str(rally.get("base_url") or cfg.base_url)
    cfg.workspace = str(rally.get("workspace") or "")
    cfg.project = str(rally.get("project") or "")

    defaults = data.get("defaults") or {}
    cfg.default_priority = str(defaults.get("priority") or cfg.default_priority)

    for k, v in (data.get("priority_synonyms") or {}).items():
        cfg.priority_synonyms[str(k).lower()] = [str(x) for x in (v if isinstance(v, list) else [v])]
    for k, v in (data.get("type_keywords") or {}).items():
        if k in cfg.type_keywords and isinstance(v, list):
            cfg.type_keywords[k] = [str(x) for x in v]

    cfg.max_attachment_mb = float((data.get("attachments") or {}).get("max_mb", cfg.max_attachment_mb))

    dup = data.get("duplicates") or {}
    cfg.duplicates_enabled = bool(dup.get("enabled", cfg.duplicates_enabled))
    cfg.duplicates_threshold = float(dup.get("threshold", cfg.duplicates_threshold))
    cfg.duplicates_lookback = int(dup.get("lookback", cfg.duplicates_lookback))

    cfg.approval_required = bool((data.get("approvals") or {}).get("required", cfg.approval_required))

    # environment overrides
    cfg.base_url = env.get("RALLY_BASE_URL") or cfg.base_url
    cfg.workspace = env.get("RALLY_WORKSPACE") or cfg.workspace
    cfg.project = env.get("RALLY_PROJECT") or cfg.project
    cfg.default_priority = env.get("RALLY_DEFAULT_PRIORITY") or cfg.default_priority
    if env.get("RALLY_MAX_ATTACHMENT_MB"):
        cfg.max_attachment_mb = float(env["RALLY_MAX_ATTACHMENT_MB"])

    if not 0 < cfg.duplicates_threshold <= 1:
        raise ConfigError("duplicates.threshold must be between 0 and 1.")
    if not 1 <= cfg.duplicates_lookback <= 200:
        raise ConfigError("duplicates.lookback must be between 1 and 200.")
    if cfg.max_attachment_mb <= 0:
        raise ConfigError("attachments.max_mb must be positive.")
    cfg.base_url = cfg.base_url.rstrip("/")
    return cfg
