"""Thin Rally WSAPI v2.0 client (stdlib only): auth, retries, runtime lookups, creation."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request

from .config import Config
from .validation import TYPES, to_html

MAX_RETRIES = 4
TIMEOUT = 60


class RallyError(Exception):
    pass


def _oid(ref: str) -> str:
    return ref.rstrip("/").split("/")[-1]


class RallyClient:
    def __init__(self, cfg: Config, key: str):
        if not key:
            raise RallyError("API key is empty.")
        self.cfg = cfg
        self.key = key
        self.base = cfg.base_url
        self.api = self.base + "/slm/webservice/v2.0"
        self._cache: dict = {}

    # ------------------------------------------------------------------ HTTP
    def _scrub(self, s: str) -> str:
        return s.replace(self.key, "***")

    def _url(self, path: str, params: dict | None) -> str:
        if path.startswith("http"):
            if urllib.parse.urlparse(path).netloc != urllib.parse.urlparse(self.base).netloc:
                raise RallyError("Refusing to send the API key to a host other than the configured Rally host.")
            url = path
        else:
            url = self.api + path
        clean = {k: v for k, v in (params or {}).items() if v is not None}
        if clean:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(clean)
        return url

    @staticmethod
    def _delay(err: urllib.error.HTTPError, attempt: int) -> float:
        ra = err.headers.get("Retry-After") if err.headers else None
        if ra and str(ra).isdigit():
            return min(int(ra), 60)
        return min(2 ** (attempt + 1), 30)

    def _http_message(self, status: int, raw: str) -> str:
        try:
            data = json.loads(raw)
            detail = "; ".join(e for v in data.values() if isinstance(v, dict) for e in v.get("Errors", []))
        except Exception:
            detail = raw[:200]
        hints = {
            401: "Authentication failed: RALLY_API_KEY is invalid, expired or revoked.",
            403: "Permission denied: your Rally user lacks rights on this workspace/project.",
            404: "Not found: check base_url and the workspace/project names.",
            429: "Rate limit still exceeded after retries; wait a minute and retry.",
        }
        return self._scrub(f"{hints.get(status, f'Rally returned HTTP {status}.')} {detail}".strip())

    def request(self, method: str, path: str, params: dict | None = None, body: dict | None = None) -> dict:
        url = self._url(path, params)
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"ZSESSIONID": self.key, "Accept": "application/json"}
        if data:
            headers["Content-Type"] = "application/json"
        idempotent = method == "GET"  # never blindly retry a create: it could duplicate the ticket
        payload = b""
        for attempt in range(MAX_RETRIES + 1):
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                    payload = resp.read()
                break
            except urllib.error.HTTPError as e:
                raw = e.read().decode("utf-8", "replace")
                retryable = e.code in (429, 503) or (e.code >= 500 and idempotent)
                if retryable and attempt < MAX_RETRIES:
                    time.sleep(self._delay(e, attempt))
                    continue
                raise RallyError(self._http_message(e.code, raw))
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                if idempotent and attempt < MAX_RETRIES:
                    time.sleep(2 ** attempt)
                    continue
                raise RallyError("Network error calling Rally: " + self._scrub(str(e)))
        try:
            result = json.loads(payload.decode("utf-8"))
        except ValueError:
            raise RallyError("Rally returned a non-JSON response (check base_url).")
        for v in result.values():  # Rally can answer HTTP 200 with errors inside
            if isinstance(v, dict) and v.get("Errors"):
                raise RallyError(self._scrub("; ".join(v["Errors"])))
        return result

    def results(self, path: str, params: dict | None = None) -> list:
        p = {"pagesize": "200"}
        p.update(params or {})
        return self.request("GET", path, p)["QueryResult"]["Results"]

    # --------------------------------------------------------------- lookups
    def _find(self, kind: str, name: str, extra: dict | None = None) -> dict:
        safe = name.replace('"', '\\"')
        params = {"query": f'(Name = "{safe}")', "fetch": "Name,ObjectID"}
        params.update(extra or {})
        hits = self.results(f"/{kind}", params)
        if not hits:
            raise RallyError(f"{kind.title()} '{name}' not found (or not visible to you).")
        if len(hits) > 1:
            raise RallyError(f"{kind.title()} name '{name}' is ambiguous ({len(hits)} matches).")
        return {"ref": hits[0]["_ref"], "name": hits[0]["Name"], "oid": str(hits[0]["ObjectID"])}

    def context(self, project_name: str | None = None) -> dict:
        """Workspace + project, from config/env names or the user's profile defaults."""
        ck = ("ctx", project_name)
        if ck in self._cache:
            return self._cache[ck]
        ws_name, pr_name = self.cfg.workspace, project_name or self.cfg.project
        ws = proj = None
        if ws_name:
            ws = self._find("workspace", ws_name)
        if not ws or not pr_name:
            user = self.request("GET", "/user", {"fetch": "UserProfile"})["User"]
            prof = self.request("GET", user["UserProfile"]["_ref"],
                                {"fetch": "DefaultWorkspace,DefaultProject"})["UserProfile"]
            if not ws:
                dw = prof.get("DefaultWorkspace")
                if not dw:
                    raise RallyError("No default workspace on your Rally profile; set rally.workspace.")
                ws = {"ref": dw["_ref"], "name": dw["_refObjectName"], "oid": _oid(dw["_ref"])}
            if not pr_name:
                dp = prof.get("DefaultProject")
                if not dp:
                    raise RallyError("No default project on your Rally profile; set rally.project.")
                proj = {"ref": dp["_ref"], "name": dp["_refObjectName"], "oid": _oid(dp["_ref"])}
        if pr_name:
            proj = self._find("project", pr_name, {"workspace": ws["ref"]})
        self._cache[ck] = {"workspace": ws, "project": proj}
        return self._cache[ck]

    def allowed_values(self, type_key: str, attr: str = "Priority") -> list | None:
        """Allowed values for a field, or None if the type has no such field."""
        ck = ("av", type_key, attr)
        if ck in self._cache:
            return self._cache[ck]
        ws = self.context()["workspace"]["ref"]
        tds = self.results("/typedefinition", {
            "query": f'(TypePath = "{TYPES[type_key]["path"]}")', "fetch": "Attributes", "workspace": ws})
        values = None
        if tds:
            attrs = self.results(tds[0]["Attributes"]["_ref"], {
                "query": f'(ElementName = "{attr}")', "fetch": "ElementName,AllowedValues"})
            if attrs:
                av = self.results(attrs[0]["AllowedValues"]["_ref"])
                values = [v["StringValue"] for v in av if v.get("StringValue")]
        self._cache[ck] = values
        return values

    def recent_artifacts(self, type_key: str, project_name: str | None, limit: int) -> list:
        """Newest open items of this type in the project (used for duplicate detection)."""
        ck = ("recent", type_key, project_name, limit)
        if ck in self._cache:
            return self._cache[ck]
        info, ctx = TYPES[type_key], self.context(project_name)
        rows = self.results(f"/{info['endpoint']}", {
            "workspace": ctx["workspace"]["ref"], "project": ctx["project"]["ref"],
            "projectScopeDown": "false", "query": info["open_query"],
            "order": "CreationDate desc", "fetch": "FormattedID,Name", "pagesize": str(limit)})
        out = [{"id": r["FormattedID"], "name": r["Name"], "ref": r["_ref"]} for r in rows]
        self._cache[ck] = out
        return out

    # -------------------------------------------------------------- creation
    def create_ticket(self, item: dict) -> dict:
        """item keys: type, title, description, priority (resolved value or None), project."""
        info = TYPES[item["type"]]
        ctx = self.context(item.get("project"))
        ws_ref, proj = ctx["workspace"]["ref"], ctx["project"]
        obj = {"Name": item["title"], "Description": to_html(item["description"]),
               "Project": {"_ref": proj["ref"]}, "Workspace": {"_ref": ws_ref}}
        if item.get("priority"):
            obj["Priority"] = item["priority"]
        res = self.request("POST", f"/{info['endpoint']}/create",
                           {"workspace": ws_ref, "fetch": "FormattedID,ObjectID,Name"},
                           {info["wrapper"]: obj})
        created = res["CreateResult"]["Object"]
        return {"id": created["FormattedID"], "ref": created["_ref"], "type": info["label"],
                "priority": item.get("priority"), "project": proj["name"],
                "link": f"{self.base}/#/{proj['oid']}d/detail/{info['detail']}/{created['ObjectID']}"}

    def create_attachment_content(self, b64: str) -> str:
        res = self.request("POST", "/attachmentcontent/create", body={"AttachmentContent": {"Content": b64}})
        return res["CreateResult"]["Object"]["_ref"]

    def create_attachment(self, artifact_ref: str, content_ref: str, name: str, mime: str, size: int) -> None:
        self.request("POST", "/attachment/create", body={"Attachment": {
            "Artifact": {"_ref": artifact_ref}, "Content": {"_ref": content_ref},
            "Name": name, "ContentType": mime, "Size": size}})
