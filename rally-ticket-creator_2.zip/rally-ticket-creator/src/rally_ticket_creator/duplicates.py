"""Duplicate detection: score a new title against recent open items and earlier items in the batch."""
from __future__ import annotations

import re
from difflib import SequenceMatcher

_STOP = {"a", "an", "the", "of", "to", "in", "on", "for", "and", "or", "is", "are", "be", "with",
         "at", "by", "from", "it", "this", "that", "as", "not"}


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", s.lower()).strip()


def _tokens(s: str) -> set:
    return {t for t in _norm(s).split() if t not in _STOP}


def similarity(a: str, b: str) -> float:
    """0..1 blend of character-level and word-level similarity."""
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return 0.0
    seq = SequenceMatcher(None, na, nb).ratio()
    ta, tb = _tokens(a), _tokens(b)
    jac = len(ta & tb) / len(ta | tb) if ta and tb else 0.0
    return round(0.6 * seq + 0.4 * jac, 4)


def find_in_candidates(title: str, candidates: list, threshold: float, limit: int = 3) -> list:
    """candidates: [{'id','name',...}]. Returns the best matches at or above threshold."""
    scored = []
    for c in candidates:
        s = similarity(title, c["name"])
        if s >= threshold:
            scored.append({"id": c["id"], "name": c["name"], "score": s})
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:limit]


def find_duplicates(client, item: dict, cfg) -> list:
    """Compare against recent open items of the same type in the item's project."""
    candidates = client.recent_artifacts(item["type"], item.get("project"), cfg.duplicates_lookback)
    return find_in_candidates(item["title"], candidates, cfg.duplicates_threshold)


def find_batch_duplicates(items: list, threshold: float) -> dict:
    """{index: [earlier items it resembles]} for items of the same type within one batch."""
    out: dict = {}
    for i, item in enumerate(items):
        earlier = [{"id": f"#{o['index']}", "name": o["title"]} for o in items[:i] if o["type"] == item["type"]]
        hits = find_in_candidates(item["title"], earlier, threshold)
        if hits:
            out[item["index"]] = hits
    return out
