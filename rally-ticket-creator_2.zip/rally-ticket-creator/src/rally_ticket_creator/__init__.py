"""Create Rally Defects and User Stories from the command line or a Claude Code skill."""

__version__ = "0.1.0"
