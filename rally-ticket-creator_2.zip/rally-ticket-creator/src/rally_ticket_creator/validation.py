"""Pure input validation and normalisation. No network, no filesystem."""
from __future__ import annotations

import html
import re
from typing import Iterable, Optional

MAX_NAME_LEN = 256

TYPES = {
    "defect": {"label": "Defect", "path": "Defect", "endpoint": "defect", "wrapper": "Defect",
               "detail": "defect", "open_query": '(State != "Closed")'},
    "story": {"label": "User Story", "path": "HierarchicalRequirement",
              "endpoint": "hierarchicalrequirement", "wrapper": "HierarchicalRequirement",
              "detail": "userstory", "open_query": '(ScheduleState != "Accepted")'},
}
TYPE_ALIASES = {
    "defect": "defect", "bug": "defect", "de": "defect",
    "story": "story", "user story": "story", "userstory": "story", "us": "story",
    "backlog": "story", "backlog item": "story", "feature": "story",
    "hierarchicalrequirement": "story",
}


class ValidationError(ValueError):
    pass


def to_html(text: str) -> str:
    """Rally descriptions are HTML. Pass HTML through; make plain text safe."""
    if re.search(r"</?(p|br|div|ul|ol|li|b|i|strong|em|a|h[1-6]|table|pre|code)\b", text, re.I):
        return text
    return html.escape(text.replace("\r\n", "\n")).replace("\n", "<br>")


def _keyword_regex(words: Iterable[str]) -> Optional["re.Pattern[str]"]:
    words = [w for w in words if w]
    if not words:
        return None
    return re.compile(r"(?<!\w)(?:" + "|".join(re.escape(w) for w in words) + r")(?!\w)", re.I)


def infer_type(title: str, description: str, keywords: dict) -> Optional[str]:
    """'defect', 'story', or None when the wording is ambiguous or has no signal."""
    text = f"{title}\n{description}"
    d_re, s_re = _keyword_regex(keywords.get("defect", [])), _keyword_regex(keywords.get("story", []))
    d = bool(d_re and d_re.search(text))
    s = bool(s_re and s_re.search(text))
    if d and not s:
        return "defect"
    if s and not d:
        return "story"
    return None


def normalize(raw: object, idx: int, type_keywords: dict) -> tuple:
    """Validate one ticket request. Returns (ticket_dict | None, [error, ...])."""
    if not isinstance(raw, dict):
        return None, [f"ticket #{idx}: must be an object"]
    errors = []
    title = str(raw.get("title") or "").strip()
    desc = str(raw.get("description") or "").strip()
    if not title:
        errors.append("title is required")
    elif len(title) > MAX_NAME_LEN:
        errors.append(f"title is {len(title)} chars; Rally allows {MAX_NAME_LEN}")
    if not desc:
        errors.append("description is required")

    tkey, inferred = None, False
    if raw.get("type"):
        tkey = TYPE_ALIASES.get(str(raw["type"]).strip().lower())
        if not tkey:
            errors.append(f"unknown type '{raw['type']}' (use defect or story)")
    elif title and desc:
        tkey, inferred = infer_type(title, desc, type_keywords), True

    att = raw.get("attachments") or []
    if isinstance(att, str):
        att = [att]
    if not isinstance(att, list):
        errors.append("attachments must be a list of file paths")
        att = []

    return {
        "index": idx, "title": title, "description": desc, "type": tkey, "type_inferred": inferred,
        "priority_requested": str(raw["priority"]).strip() if raw.get("priority") else None,
        "project": str(raw["project"]).strip() if raw.get("project") else None,
        "attachment_paths": [str(p) for p in att],
    }, errors


def resolve_priority(values: Optional[list], requested: Optional[str], synonyms: dict,
                     default: str) -> tuple:
    """Map a requested/default priority onto the instance's allowed values.

    Returns (value_or_None, note_or_None). Raises ValidationError for an invalid explicit value.
    `values` is None when the artifact type has no Priority field.
    """
    if values is None:
        return None, "type has no Priority field in this workspace; priority skipped"
    by_lower = {v.lower(): v for v in values}
    req = (requested or "").strip()
    if req:
        if req.lower() in by_lower:
            return by_lower[req.lower()], None
        for cand in synonyms.get(req.lower(), []):
            if cand.lower() in by_lower:
                return by_lower[cand.lower()], f"priority '{req}' mapped to '{by_lower[cand.lower()]}'"
        raise ValidationError(f"Priority '{req}' is not valid. Allowed: {', '.join(values)}")
    for cand in (default, "Normal", "Medium"):
        if cand and cand.lower() in by_lower:
            return by_lower[cand.lower()], None
    usable = [v for v in values if v.lower() != "none"]
    if usable:
        return usable[len(usable) // 2], "no default priority available; used the middle value"
    return None, "no usable priority values; priority left unset"
