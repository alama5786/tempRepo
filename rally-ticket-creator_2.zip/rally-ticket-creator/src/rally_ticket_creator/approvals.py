"""Plan -> approve -> create.

`plan` writes a preview file whose digest covers exactly what will be created (titles,
descriptions, types, resolved priorities, attachment contents). `create --approve <digest>`
refuses to run if the plan was edited afterwards or the digest does not match, so what the
user approved is what gets created.

This guards against drift between preview and creation. It is not a security boundary
against a malicious agent: the agent that runs the commands also sees the digest.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

PLAN_VERSION = 1
MIN_TOKEN_LEN = 12
CREATABLE = ("ready", "possible_duplicate")


class ApprovalError(Exception):
    pass


def _payload(item: dict) -> dict:
    return {
        "index": item["index"], "status": item["status"], "type": item["type"],
        "title": item["title"], "description": item["description"], "priority": item.get("priority"),
        "project": item.get("project"),
        "attachments": [{"path": a["path"], "size": a["size"], "sha256": a["sha256"]}
                        for a in item.get("attachments", [])],
    }


def compute_digest(items: list) -> str:
    payload = [_payload(i) for i in items if i["status"] in CREATABLE]
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def build_plan(items: list) -> dict:
    return {"version": PLAN_VERSION, "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "digest": compute_digest(items), "items": items}


def save_plan(plan: dict, path: str) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(plan, fh, indent=2)


def load_plan(path: str) -> dict:
    try:
        with open(path, encoding="utf-8") as fh:
            plan = json.load(fh)
    except FileNotFoundError:
        raise ApprovalError(f"Plan file not found: {path}. Run the plan command first.")
    except ValueError as e:
        raise ApprovalError(f"Plan file is not valid JSON: {e}")
    if plan.get("version") != PLAN_VERSION or "items" not in plan or "digest" not in plan:
        raise ApprovalError("Unrecognised plan file; create a new one with the plan command.")
    if compute_digest(plan["items"]) != plan["digest"]:
        raise ApprovalError("Plan file was modified after it was generated; run the plan command again.")
    return plan


def verify_approval(plan: dict, token: str | None) -> None:
    if not token:
        raise ApprovalError("Approval required: show the plan to the user, then rerun create with "
                            "--approve <digest> once they agree.")
    token = token.strip().lower()
    if len(token) < MIN_TOKEN_LEN or not plan["digest"].startswith(token):
        raise ApprovalError("Approval digest does not match this plan. Re-show the plan and approve it again.")


def select_for_creation(plan: dict, allow_duplicates: set) -> tuple:
    """Returns (to_create, skipped) where skipped is [(item, reason)]."""
    to_create, skipped = [], []
    for item in plan["items"]:
        st = item["status"]
        if item.get("created"):
            skipped.append((item, f"already created as {item['created']['id']}"))
        elif st == "ready":
            to_create.append(item)
        elif st == "possible_duplicate":
            if item["index"] in allow_duplicates:
                to_create.append(item)
            else:
                skipped.append((item, "possible duplicate; not confirmed"))
        elif st == "needs_type":
            skipped.append((item, "type undecided"))
        else:
            skipped.append((item, "invalid"))
    return to_create, skipped


def render_preview(plan: dict, plan_path: str) -> str:
    labels = {"ready": "READY", "possible_duplicate": "DUPLICATE?", "needs_type": "NEEDS_TYPE", "invalid": "INVALID"}
    lines = []
    for it in plan["items"]:
        head = f"#{it['index']}  {labels.get(it['status'], it['status'].upper()):<11}"
        if it["status"] == "invalid":
            lines.append(f"{head} {it['title'] or '(no title)'}: " + "; ".join(it["errors"]))
            continue
        if it["status"] == "needs_type":
            lines.append(f"{head} \"{it['title']}\": cannot tell Defect from User Story")
            continue
        tag = " (inferred)" if it.get("type_inferred") else ""
        label = "Defect" if it["type"] == "defect" else "User Story"
        lines.append(f"{head} {label}{tag}  priority={it.get('priority') or 'unset'}  "
                     f"project={it.get('project_name') or 'default'}  \"{it['title']}\"")
        if it.get("priority_note"):
            lines.append(f"      note: {it['priority_note']}")
        for d in it.get("duplicates", []):
            lines.append(f"      similar: {d['id']} \"{d['name']}\" ({d['score']:.2f})")
        for a in it.get("attachments", []):
            size = f"{a['size']} B" if a["size"] < 1024 else f"{a['size'] // 1024} KB"
            lines.append(f"      attach: {a['name']} ({size})")
        for e in it.get("attachment_errors", []):
            lines.append(f"      ! attachment skipped: {e}")
        if it.get("notes"):
            for n in it["notes"]:
                lines.append(f"      note: {n}")
    lines.append(f"PLAN_FILE: {plan_path}")
    lines.append(f"PLAN_DIGEST: {plan['digest']}")
    return "\n".join(lines)
