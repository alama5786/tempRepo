---
name: rally-ticket-creator
description: Create Rally tickets (Defects and User Stories / backlog items) through the Rally REST API with a preview-and-approve step and duplicate checking. Use when the user says "create a Rally ticket", "log a Rally defect", "raise a bug in Rally", "add this to the Rally backlog", "new Rally story", "/rally-ticket-creator", or lists items for the Rally board or morning board meeting. Supports title, description, priority, optional attachments, and several tickets per request. Uses the RALLY_API_KEY environment variable; no MCP.
---

# Rally ticket creator

Wraps the `rally-ticket-creator` CLI (Python package in `src/rally_ticket_creator/`). Run commands from the repository root. If the command is not found, run `pip install -e .` once.

Read `references/ticket-rules.md` before drafting any title or description.

## Hard rules

- Never print, echo or ask for `RALLY_API_KEY`. Do not run `env`, `printenv` or `echo $RALLY_API_KEY`.
- Use only this CLI for Rally access. No MCP, no curl with the key.
- Never create a ticket before the user has approved the plan in chat (unless `check` reports "approvals: not required").
- Never invent facts (versions, steps to reproduce, names, dates). Use only what the user gave.

## Workflow

1. **Gather input.** Minimum: a title and a description. Optional: type, priority, project name, attachment paths. If the user gave one line, draft title and description per `ticket-rules.md`.
2. **First use in a session, or after any error:** run `rally-ticket-creator check`. It verifies auth and prints workspace, project, valid priorities and whether approvals are required.
3. **Write the input.** One ticket: use flags (`--title`, `--description`, `--type`, `--priority`, `--attach`). Several tickets, or text with awkward quoting: write a JSON file with the Write tool in the scratchpad or temp directory:
   ```json
   {"tickets": [
     {"title": "Login times out after 30s", "description": "Users get a 504 on the portal.", "priority": "high", "attachments": ["C:\\temp\\error.png"]},
     {"title": "Add CSV export to claims report", "description": "Finance wants CSV export.", "type": "story"}
   ]}
   ```
   Fields: `title`, `description` (required); `type` (`defect`|`story`), `priority`, `project`, `attachments` (optional).
4. **Plan (creates nothing):** `rally-ticket-creator plan --json <file>` (or flags). The output lists each item as READY, DUPLICATE?, NEEDS_TYPE or INVALID, plus a `PLAN_DIGEST`.
5. **Resolve and confirm with the user.** Show the preview in plain words (type, title, priority, attachments). Then:
   - NEEDS_TYPE: ask "Defect or User Story?", fix the input, rerun `plan`.
   - INVALID: fix the stated problem (for example an invalid priority; offer the allowed values), rerun `plan`.
   - DUPLICATE?: show the similar existing item(s) and ask whether to create anyway. Note the item number.
   - Attachment skipped: tell the user which file and why.
   - Ask for a clear yes. Any edit after a yes means rerun `plan` and confirm again.
6. **Create:** `rally-ticket-creator create --plan .rally-plan.json --approve <PLAN_DIGEST> [--allow-duplicate N ...]`. Pass `--allow-duplicate N` only for items the user confirmed. If the plan was edited or the digest is wrong, the command refuses; rerun `plan`.
7. **Report** one line per ticket: `DE1234 - Title - <link>`, plus any attachment failures or skipped items. Nothing else.

If `check` says approvals are not required, `create` also accepts `--json`/flags directly (it still skips duplicates unless `--allow-duplicate N` is given).

## Exit codes

| Code | Meaning | Action |
|---|---|---|
| 0 | Success | Report IDs and links |
| 1 | Something failed or invalid | Report what succeeded, quote failures, offer to fix and retry only the failed ones |
| 2 | Setup, config or approval error | Relay the message. Missing key: point to README.md. Do not retry blindly |
| 3 | A decision is needed | Ask the user (type or duplicate), then continue |

A created ticket is recorded in the plan file, so rerunning the same `create` will not create it twice.

## Troubleshooting

- 401: key invalid or revoked. 403: no rights on that project. Wrong project: set `rally.project` in `config/rally.yaml` or pass `project` per ticket.
- Different Rally host: set `rally.base_url` in `config/rally.yaml` or `RALLY_BASE_URL`.
- Config is optional; see `config/rally.example.yaml`.
