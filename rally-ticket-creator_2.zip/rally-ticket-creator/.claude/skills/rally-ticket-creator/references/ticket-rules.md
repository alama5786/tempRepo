# Ticket rules

Edit this file to match your team's conventions. The agent reads it before drafting tickets.

## Choosing the type

- Defect: something that used to work or should work is wrong (error, crash, wrong output, outage, regression).
- User Story (backlog item): new or changed capability someone wants (add, allow, support, improve).
- If the wording fits both (for example "add a retry because the load fails"), ask. Do not guess.
- The CLI infers from keywords and returns NEEDS_TYPE when unsure; an explicit type from the user always wins.

## Titles

- 5 to 12 words, specific, no trailing period, under 256 characters.
- Defect: "<Where> <what goes wrong>" e.g. "Nightly ETL fails on claims load".
- Story: "<Capability> for <who/where>" e.g. "CSV export for claims report".
- Keep the user's own terms for systems, jobs and screens. Do not rename them.
- No ticket IDs, dates or "URGENT" in the title; use the priority field.

## Descriptions

Plain text is fine; blank lines become line breaks. Use only information the user provided.

Defect:
```
What happens: <observed behaviour and error text>
Expected: <expected behaviour, only if the user said so>
Where: <system / environment / job, if given>
Impact: <who or what is affected, if given>
Steps to reproduce: <only if given>
```

Story:
```
Need: <what is wanted and by whom>
Why: <business reason, if given>
Acceptance: <criteria, only if given>
```

Omit any line you have no information for. Never write "unknown" or "TBD" placeholders, and never fabricate details.
Mark an assumption explicitly, for example "Assumed: production environment (not stated)".

## Priority

- Default is applied automatically when none is given (config `defaults.priority`). Do not ask about it.
- Accepted shorthand: critical/urgent/blocker/p1, high/p2, medium/normal/p3, low/p4. They map onto this Rally instance's real values.
- Set a high priority only when the user says so or describes production impact in their words. Do not escalate on your own.

## Attachments

- Only files the user names. Check the path exists before planning; the CLI skips missing, empty or oversized files and reports why.
- Default size limit is 5 MB (config `attachments.max_mb`).
- Never attach files containing credentials or personal data unless the user explicitly asks.

## Duplicates

- A possible duplicate is a similar open item in the same project (or an earlier item in the same batch).
- Show the existing ID and title to the user. Create anyway only if the user says so.

## Batches

- One ticket per distinct problem or request. Split numbered or bulleted lists into separate tickets.
- Do not merge items, and do not drop any: if something cannot be created, say which and why.
