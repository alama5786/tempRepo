# rally-ticket-creator

Create Rally Defects and User Stories from the command line or from Claude Code, using the Rally WSAPI over HTTPS with an API key. No MCP. Python 3.9+, one dependency (PyYAML, for the optional config file).

## How it works

```
plan   validate, infer type, map priority, check files, look for duplicates  -> preview + digest (creates nothing)
         user reviews the preview
create re-verifies the digest, then creates tickets and uploads attachments
```

```
rally-ticket-creator/
├── .claude/skills/rally-ticket-creator/
│   ├── SKILL.md                    agent workflow and rules
│   └── references/ticket-rules.md  team conventions for titles, descriptions, priority
├── src/rally_ticket_creator/
│   ├── cli.py          commands: check, plan, create
│   ├── config.py       defaults < config/rally.yaml < env vars; API key from env only
│   ├── validation.py   input checks, type inference, priority mapping (pure functions)
│   ├── rally_api.py    HTTP client: auth, retries, runtime lookups, create
│   ├── duplicates.py   similarity scoring against recent open items and the batch
│   ├── attachments.py  file checks and two-step upload
│   └── approvals.py    plan file, digest, approval check
├── config/rally.example.yaml
└── tests/
```

## Setup

1. Create a Rally API key (Rally profile menu, API Keys). Read/write scope.
2. Set it as an environment variable (never in a file):
   - macOS/Linux: `export RALLY_API_KEY="..."` in `~/.zshrc` or `~/.bashrc`
   - Windows PowerShell: `setx RALLY_API_KEY "..."`, then open a new terminal
3. Install from the repo root (a virtual environment is recommended):
   ```
   pip install -e ".[dev]"
   ```
4. Optional: `cp config/rally.example.yaml config/rally.yaml` and edit (workspace, project, default priority, duplicate threshold, approvals). `config/rally.yaml` is git-ignored.
5. Verify: `rally-ticket-creator check`

The skill lives in the project's `.claude/skills/`, so Claude Code picks it up when started in this repo. To use it from any directory, copy `.claude/skills/rally-ticket-creator` to `~/.claude/skills/` (and keep the package installed with `pip install -e`).

## Use

From Claude Code:
```
/rally-ticket-creator defect: nightly ETL fails on the claims load, high priority
```
Claude drafts the ticket, runs `plan`, shows you the preview (including similar existing items), and creates it only after you agree.

From a terminal:
```
rally-ticket-creator plan --title "Nightly ETL fails on claims load" --description "Job errors out nightly." --priority high
rally-ticket-creator create --plan .rally-plan.json --approve <digest from plan>
```

Example plan output:
```
#1  READY       Defect (inferred)  priority=High Attention  project=Platform Team  "Nightly ETL fails on claims load"
      similar: DE812 "ETL fails on claims load" (0.88)      <- only on a DUPLICATE? item
PLAN_FILE: .rally-plan.json
PLAN_DIGEST: 3f9c...
```
Example create output:
```
OK  DE1234  Defect (type inferred)  Nightly ETL fails on claims load
    priority: High Attention  project: Platform Team
    https://rally1.rallydev.com/#/123456d/detail/defect/987654321
```

## Behaviour notes

- Exit codes: 0 ok, 1 failure/invalid item, 2 setup/config/approval error, 3 decision needed (type or duplicate).
- The approval digest ties the preview to the creation (title, description, type, resolved priority, attachment contents). It detects drift or edits; it is not a security boundary against the agent that runs the commands.
- Created tickets are recorded in the plan file, so rerunning `create` on the same plan does not duplicate them.
- Set `approvals.required: false` to allow `create` directly from `--json`/flags (duplicates are still skipped unless `--allow-duplicate N`).
- Duplicate detection is a text-similarity heuristic over the newest open items of the same type in the project (up to 200). It will miss older items and may flag unrelated ones; tune `duplicates.threshold`.

## Develop

```
pytest
```
Tests use fakes for the network (no Rally access needed).
