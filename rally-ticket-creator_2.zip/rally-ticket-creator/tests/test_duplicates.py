from types import SimpleNamespace

from rally_ticket_creator.duplicates import (find_batch_duplicates, find_duplicates,
                                             find_in_candidates, similarity)


def test_identical_titles_score_one():
    assert similarity("Login times out", "login times out!") == 1.0


def test_unrelated_titles_score_low():
    assert similarity("Nightly ETL fails on claims load", "Add CSV export to finance report") < 0.4


def test_empty_title_scores_zero():
    assert similarity("", "anything") == 0.0


def test_near_duplicate_scores_high():
    assert similarity("Login times out after 30 seconds", "Login timing out after 30 seconds") > 0.75


def test_find_in_candidates_threshold_and_order():
    cands = [{"id": "DE1", "name": "Claims report totals wrong"},
             {"id": "DE2", "name": "Claims report totals are wrong for Q3"},
             {"id": "DE3", "name": "Unrelated printer problem"}]
    hits = find_in_candidates("Claims report totals wrong for Q3", cands, 0.6)
    assert [h["id"] for h in hits] == ["DE2", "DE1"]
    assert all(h["score"] >= 0.6 for h in hits)


def test_find_in_candidates_limit():
    cands = [{"id": f"DE{i}", "name": "same title here"} for i in range(10)]
    assert len(find_in_candidates("same title here", cands, 0.5, limit=3)) == 3


class FakeClient:
    def __init__(self, rows):
        self.rows, self.calls = rows, []

    def recent_artifacts(self, type_key, project, limit):
        self.calls.append((type_key, project, limit))
        return self.rows


def test_find_duplicates_uses_config_and_client():
    cfg = SimpleNamespace(duplicates_threshold=0.8, duplicates_lookback=50)
    client = FakeClient([{"id": "DE9", "name": "ETL fails on claims load"}])
    item = {"type": "defect", "title": "ETL fails on claims load", "project": None}
    hits = find_duplicates(client, item, cfg)
    assert hits[0]["id"] == "DE9"
    assert client.calls == [("defect", None, 50)]


def test_batch_duplicates_same_type_only():
    items = [{"index": 1, "type": "defect", "title": "Login page crashes"},
             {"index": 2, "type": "defect", "title": "Login page crashes!"},
             {"index": 3, "type": "story", "title": "Login page crashes"}]
    out = find_batch_duplicates(items, 0.8)
    assert list(out) == [2]
    assert out[2][0]["id"] == "#1"
