import io
import json
import urllib.error

import pytest

from rally_ticket_creator import rally_api
from rally_ticket_creator.config import Config
from rally_ticket_creator.rally_api import RallyClient, RallyError

BASE = "https://rally.example.com"
API = BASE + "/slm/webservice/v2.0"
KEY = "super-secret-key"


class FakeResp:
    def __init__(self, body):
        self._b = json.dumps(body).encode()

    def read(self):
        return self._b

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def http_error(code, body=None, headers=None):
    return urllib.error.HTTPError(BASE, code, "msg", headers or {}, io.BytesIO(json.dumps(body or {}).encode()))


@pytest.fixture
def net(monkeypatch):
    """Queue of responses (dict body or Exception); records requests and sleeps."""
    state = {"queue": [], "requests": [], "sleeps": []}

    def fake_urlopen(req, timeout=None):
        state["requests"].append(req)
        nxt = state["queue"].pop(0)
        if isinstance(nxt, Exception):
            raise nxt
        return FakeResp(nxt)

    monkeypatch.setattr(rally_api.urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(rally_api.time, "sleep", lambda s: state["sleeps"].append(s))
    return state


@pytest.fixture
def client():
    return RallyClient(Config(base_url=BASE), KEY)


def test_empty_key_rejected():
    with pytest.raises(RallyError):
        RallyClient(Config(base_url=BASE), "")


def test_key_sent_as_header_not_in_url(net, client):
    net["queue"] = [{"QueryResult": {"Results": []}}]
    client.results("/defect", {"query": "(Name = \"x\")"})
    req = net["requests"][0]
    assert req.headers["Zsessionid"] == KEY
    assert KEY not in req.full_url


def test_get_retries_429_honouring_retry_after(net, client):
    net["queue"] = [http_error(429, headers={"Retry-After": "3"}), {"QueryResult": {"Results": [1]}}]
    assert client.results("/defect") == [1]
    assert net["sleeps"] == [3]


def test_get_retries_server_errors_then_gives_up(net, client):
    net["queue"] = [http_error(500)] * (rally_api.MAX_RETRIES + 1)
    with pytest.raises(RallyError, match="HTTP 500"):
        client.results("/defect")
    assert len(net["requests"]) == rally_api.MAX_RETRIES + 1


def test_post_is_not_retried_on_500(net, client):
    net["queue"] = [http_error(500), {"CreateResult": {"Object": {}}}]
    with pytest.raises(RallyError):
        client.request("POST", "/defect/create", body={"Defect": {}})
    assert len(net["requests"]) == 1


def test_post_is_retried_on_429(net, client):
    net["queue"] = [http_error(429), {"CreateResult": {"Object": {"ok": 1}}}]
    out = client.request("POST", "/defect/create", body={"Defect": {}})
    assert out["CreateResult"]["Object"] == {"ok": 1}
    assert len(net["requests"]) == 2


def test_post_network_error_not_retried(net, client):
    net["queue"] = [urllib.error.URLError("boom")]
    with pytest.raises(RallyError, match="Network error"):
        client.request("POST", "/defect/create", body={})
    assert len(net["requests"]) == 1


def test_401_message_is_clear_and_never_leaks_key(net, client):
    net["queue"] = [http_error(401, {"OperationResult": {"Errors": [f"bad {KEY}"]}})]
    with pytest.raises(RallyError) as e:
        client.request("GET", "/user")
    assert "invalid" in str(e.value) and KEY not in str(e.value)


def test_errors_inside_http_200_are_raised(net, client):
    net["queue"] = [{"CreateResult": {"Errors": ["Could not create: Name is required"]}}]
    with pytest.raises(RallyError, match="Name is required"):
        client.request("POST", "/defect/create", body={})


def test_refuses_to_send_key_to_other_host(client):
    with pytest.raises(RallyError, match="other than"):
        client.request("GET", "https://evil.example.org/steal")


def profile_responses():
    return [
        {"User": {"UserProfile": {"_ref": API + "/userprofile/1"}}},
        {"UserProfile": {"DefaultWorkspace": {"_ref": API + "/workspace/10", "_refObjectName": "WS"},
                         "DefaultProject": {"_ref": API + "/project/20", "_refObjectName": "Proj"}}},
    ]


def test_context_uses_profile_defaults_and_caches(net, client):
    net["queue"] = profile_responses()
    ctx = client.context()
    assert ctx["workspace"]["name"] == "WS" and ctx["project"]["oid"] == "20"
    assert client.context() is ctx
    assert len(net["requests"]) == 2


def test_context_resolves_named_project(net):
    c = RallyClient(Config(base_url=BASE, project="Team A"), KEY)
    net["queue"] = profile_responses() + [
        {"QueryResult": {"Results": [{"_ref": API + "/project/77", "Name": "Team A", "ObjectID": 77}]}}]
    assert c.context()["project"] == {"ref": API + "/project/77", "name": "Team A", "oid": "77"}
    assert 'Team A' in net["requests"][-1].full_url.replace("%22", '"').replace("+", " ")


def test_named_project_not_found(net):
    c = RallyClient(Config(base_url=BASE, project="Nope"), KEY)
    net["queue"] = profile_responses() + [{"QueryResult": {"Results": []}}]
    with pytest.raises(RallyError, match="not found"):
        c.context()


def test_allowed_values(net, client):
    net["queue"] = profile_responses() + [
        {"QueryResult": {"Results": [{"Attributes": {"_ref": API + "/typedefinition/5/Attributes"}}]}},
        {"QueryResult": {"Results": [{"AllowedValues": {"_ref": API + "/attr/7/AllowedValues"}}]}},
        {"QueryResult": {"Results": [{"StringValue": ""}, {"StringValue": "High"}, {"StringValue": "Low"}]}},
    ]
    assert client.allowed_values("defect") == ["High", "Low"]
    assert client.allowed_values("defect") == ["High", "Low"]  # cached, no new requests


def test_allowed_values_none_when_field_missing(net, client):
    net["queue"] = profile_responses() + [
        {"QueryResult": {"Results": [{"Attributes": {"_ref": API + "/typedefinition/6/Attributes"}}]}},
        {"QueryResult": {"Results": []}},
    ]
    assert client.allowed_values("story") is None


def test_create_ticket_body_and_link(net, client):
    net["queue"] = profile_responses() + [
        {"CreateResult": {"Object": {"_ref": API + "/defect/111", "FormattedID": "DE1", "ObjectID": 111},
                          "Errors": []}}]
    made = client.create_ticket({"type": "defect", "title": "T", "description": "a < b\nc",
                                 "priority": "High Attention", "project": None})
    body = json.loads(net["requests"][-1].data)["Defect"]
    assert body["Name"] == "T" and body["Priority"] == "High Attention"
    assert body["Description"] == "a &lt; b<br>c"
    assert body["Project"] == {"_ref": API + "/project/20"}
    assert made["id"] == "DE1"
    assert made["link"] == f"{BASE}/#/20d/detail/defect/111"


def test_create_ticket_omits_priority_when_none(net, client):
    net["queue"] = profile_responses() + [
        {"CreateResult": {"Object": {"_ref": API + "/hr/2", "FormattedID": "US2", "ObjectID": 2}, "Errors": []}}]
    client.create_ticket({"type": "story", "title": "T", "description": "d", "priority": None})
    body = json.loads(net["requests"][-1].data)["HierarchicalRequirement"]
    assert "Priority" not in body
