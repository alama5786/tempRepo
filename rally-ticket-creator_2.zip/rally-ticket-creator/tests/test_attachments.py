import base64

import pytest

from rally_ticket_creator.attachments import AttachmentError, check_file, upload


def test_check_file_ok(tmp_path):
    f = tmp_path / "log.txt"
    f.write_text("hello")
    info = check_file(str(f), 1024)
    assert info["name"] == "log.txt" and info["size"] == 5
    assert info["mime"] == "text/plain" and len(info["sha256"]) == 64


def test_check_file_unknown_type_defaults_to_octet_stream(tmp_path):
    f = tmp_path / "blob.zzunknown"
    f.write_bytes(b"x")
    assert check_file(str(f), 10)["mime"] == "application/octet-stream"


def test_check_file_missing(tmp_path):
    with pytest.raises(AttachmentError, match="not found"):
        check_file(str(tmp_path / "nope.png"), 1024)


def test_check_file_empty(tmp_path):
    f = tmp_path / "e.txt"
    f.write_bytes(b"")
    with pytest.raises(AttachmentError, match="empty"):
        check_file(str(f), 1024)


def test_check_file_too_large(tmp_path):
    f = tmp_path / "big.bin"
    f.write_bytes(b"x" * 2048)
    with pytest.raises(AttachmentError, match="limit"):
        check_file(str(f), 1024)


class FakeClient:
    def __init__(self):
        self.calls = []

    def create_attachment_content(self, b64):
        self.calls.append(("content", b64))
        return "ref://content/1"

    def create_attachment(self, artifact_ref, content_ref, name, mime, size):
        self.calls.append(("attachment", artifact_ref, content_ref, name, mime, size))


def test_upload_two_step_order(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("hello")
    info = check_file(str(f), 1024)
    client = FakeClient()
    upload(client, "ref://defect/9", info, 1024)
    assert client.calls[0] == ("content", base64.b64encode(b"hello").decode())
    assert client.calls[1] == ("attachment", "ref://defect/9", "ref://content/1", "a.txt", "text/plain", 5)


def test_upload_detects_file_changed_since_approval(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("hello")
    info = check_file(str(f), 1024)
    f.write_text("tampered")
    client = FakeClient()
    with pytest.raises(AttachmentError, match="changed"):
        upload(client, "ref://defect/9", info, 1024)
    assert client.calls == []
