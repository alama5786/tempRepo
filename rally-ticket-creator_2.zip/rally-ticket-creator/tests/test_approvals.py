import copy

import pytest

from rally_ticket_creator.approvals import (ApprovalError, build_plan, compute_digest, load_plan,
                                            render_preview, save_plan, select_for_creation,
                                            verify_approval)


def item(index=1, status="ready", title="Login fails", **kw):
    base = {"index": index, "status": status, "type": "defect", "type_inferred": True, "title": title,
            "description": "500 error", "priority": "High Attention", "priority_note": None,
            "project": None, "project_name": "Proj", "attachments": [], "attachment_errors": [],
            "duplicates": [], "notes": [], "errors": []}
    base.update(kw)
    return base


def test_digest_stable_and_ignores_timestamp():
    items = [item()]
    assert build_plan(items)["digest"] == build_plan(copy.deepcopy(items))["digest"]


def test_digest_changes_with_content():
    base = compute_digest([item()])
    assert compute_digest([item(title="Other")]) != base
    assert compute_digest([item(priority="Low")]) != base
    att = {"path": "/x/a.png", "name": "a.png", "size": 3, "sha256": "aa"}
    with_att = compute_digest([item(attachments=[att])])
    assert with_att != base
    assert compute_digest([item(attachments=[dict(att, sha256="bb")])]) != with_att


def test_digest_ignores_non_creatable_items_and_created_marker():
    base = compute_digest([item()])
    assert compute_digest([item(), item(index=2, status="invalid")]) == base
    assert compute_digest([item(created={"id": "DE1"})]) == base


def test_verify_requires_token():
    plan = build_plan([item()])
    with pytest.raises(ApprovalError):
        verify_approval(plan, None)


def test_verify_rejects_wrong_or_short_token():
    plan = build_plan([item()])
    with pytest.raises(ApprovalError):
        verify_approval(plan, "0" * 64)
    with pytest.raises(ApprovalError):
        verify_approval(plan, plan["digest"][:4])


def test_verify_accepts_full_and_prefix_token():
    plan = build_plan([item()])
    verify_approval(plan, plan["digest"])
    verify_approval(plan, plan["digest"][:12].upper())


def test_load_plan_round_trip_and_tamper_detection(tmp_path):
    path = str(tmp_path / "plan.json")
    save_plan(build_plan([item()]), path)
    assert load_plan(path)["items"][0]["title"] == "Login fails"
    text = open(path).read().replace("Login fails", "Something else")
    open(path, "w").write(text)
    with pytest.raises(ApprovalError, match="modified"):
        load_plan(path)


def test_load_plan_missing_file(tmp_path):
    with pytest.raises(ApprovalError, match="not found"):
        load_plan(str(tmp_path / "nope.json"))


def test_select_for_creation_rules():
    plan = build_plan([
        item(1), item(2, status="possible_duplicate"), item(3, status="possible_duplicate"),
        item(4, status="needs_type", type=None), item(5, status="invalid"),
        item(6, created={"id": "DE6", "link": "x"}),
    ])
    to_create, skipped = select_for_creation(plan, {3})
    assert [i["index"] for i in to_create] == [1, 3]
    reasons = {i["index"]: r for i, r in skipped}
    assert reasons[2].startswith("possible duplicate")
    assert reasons[4] == "type undecided" and reasons[5] == "invalid"
    assert "already created" in reasons[6]


def test_preview_shows_digest_and_duplicates():
    dup = item(2, status="possible_duplicate", duplicates=[{"id": "DE12", "name": "Login fails too", "score": 0.91}])
    text = render_preview(build_plan([item(1), dup]), ".rally-plan.json")
    assert "READY" in text and "DUPLICATE?" in text and "DE12" in text
    assert "PLAN_DIGEST:" in text
