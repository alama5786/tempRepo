import pytest

from rally_ticket_creator.config import DEFAULT_PRIORITY_SYNONYMS, DEFAULT_TYPE_KEYWORDS
from rally_ticket_creator.validation import (ValidationError, infer_type, normalize,
                                             resolve_priority, to_html)

KW = DEFAULT_TYPE_KEYWORDS
SYN = DEFAULT_PRIORITY_SYNONYMS
PRIORITIES = ["None", "Resolve Immediately", "High Attention", "Normal", "Low"]


def test_requires_title_and_description():
    _, errs = normalize({"title": " ", "description": ""}, 1, KW)
    assert "title is required" in errs and "description is required" in errs


def test_title_length_limit():
    _, errs = normalize({"title": "x" * 300, "description": "d"}, 1, KW)
    assert any("300 chars" in e for e in errs)


def test_non_object_rejected():
    t, errs = normalize("just a string", 3, KW)
    assert t is None and errs


def test_explicit_type_aliases():
    t, errs = normalize({"title": "t", "description": "d", "type": "Bug"}, 1, KW)
    assert not errs and t["type"] == "defect" and not t["type_inferred"]
    t, _ = normalize({"title": "t", "description": "d", "type": "user story"}, 1, KW)
    assert t["type"] == "story"


def test_unknown_type_is_error():
    _, errs = normalize({"title": "t", "description": "d", "type": "epic"}, 1, KW)
    assert any("unknown type" in e for e in errs)


def test_attachments_string_becomes_list():
    t, _ = normalize({"title": "t", "description": "d", "attachments": "a.png"}, 1, KW)
    assert t["attachment_paths"] == ["a.png"]


def test_attachments_wrong_shape():
    _, errs = normalize({"title": "t", "description": "d", "attachments": 5}, 1, KW)
    assert any("attachments" in e for e in errs)


@pytest.mark.parametrize("title,desc,expected", [
    ("ETL job fails nightly", "Throws an exception on load", "defect"),
    ("Page crashes on save", "regression since release", "defect"),
    ("Add CSV export", "Finance wants a new feature", "story"),
    ("As a user I want dark mode", "so that it is easier on the eyes", "story"),
    ("Add retry when the load fails", "mixed signals", None),
    ("Quarterly review notes", "nothing obvious here", None),
])
def test_infer_type(title, desc, expected):
    assert infer_type(title, desc, KW) == expected


def test_infer_type_does_not_match_inside_words():
    assert infer_type("Address book", "padding and heading", KW) is None  # 'add' inside words


def test_inferred_flag_set():
    t, _ = normalize({"title": "Login fails", "description": "500 error"}, 1, KW)
    assert t["type"] == "defect" and t["type_inferred"]


def test_to_html_escapes_plain_text():
    assert to_html("a < b\nnext") == "a &lt; b<br>next"


def test_to_html_passes_html_through():
    assert to_html("<p>hello</p>") == "<p>hello</p>"


def test_priority_exact_case_insensitive():
    assert resolve_priority(PRIORITIES, "normal", SYN, "Normal") == ("Normal", None)


def test_priority_synonym_mapping():
    value, note = resolve_priority(PRIORITIES, "critical", SYN, "Normal")
    assert value == "Resolve Immediately" and "mapped" in note
    assert resolve_priority(PRIORITIES, "high", SYN, "Normal")[0] == "High Attention"


def test_priority_invalid_lists_allowed():
    with pytest.raises(ValidationError) as e:
        resolve_priority(PRIORITIES, "urgentish", SYN, "Normal")
    assert "Allowed" in str(e.value)


def test_priority_default_when_unspecified():
    assert resolve_priority(PRIORITIES, None, SYN, "Low")[0] == "Low"
    assert resolve_priority(PRIORITIES, None, SYN, "Nonexistent")[0] == "Normal"


def test_priority_middle_value_fallback():
    value, note = resolve_priority(["P1", "P2", "P3"], None, SYN, "Normal")
    assert value == "P2" and note


def test_priority_missing_field():
    value, note = resolve_priority(None, "high", SYN, "Normal")
    assert value is None and "no Priority field" in note
