"""
Talbot BI — SQL Object Lineage Scanner with Visual Excel Flow
=============================================================
Scans a GitHub repo and produces a visual lineage Excel workbook
showing source-to-target flow using coloured boxes and arrows.

Supports: SQL (.sql), SSIS (.dtsx), SSAS (.bim), SSRS (.rdl), Power BI (.pbix)

Usage:
  python lineage_visual.py --object "dbo.Claims" --repo .
  python lineage_visual.py --object "usp_LoadClaims" --repo /path/to/repo
  python lineage_visual.py --object "DWH_FCE_Input_APMPolicy" --repo .
"""

import argparse, re, json, sys
from pathlib import Path
from collections import defaultdict, deque
from datetime import datetime
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ── Object type definitions ──────────────────────────────────────────────────
#  Each type carries: label, fill colour, font colour, stage band
TYPES = {
    "table":     {"label": "TABLE",     "fill": "DDEEFF", "font": "1F4E79", "stage": 1},
    "view":      {"label": "VIEW",      "fill": "E8F5E9", "font": "1B5E20", "stage": 2},
    "procedure": {"label": "STORED PROC","fill": "FFF9C4", "font": "F57F17", "stage": 3},
    "ssis":      {"label": "SSIS PKG",  "fill": "FCE4EC", "font": "880E4F", "stage": 4},
    "ssas":      {"label": "SSAS CUBE", "fill": "F3E5F5", "font": "4A148C", "stage": 5},
    "ssrs":      {"label": "SSRS RPT",  "fill": "E0F7FA", "font": "006064", "stage": 6},
    "powerbi":   {"label": "POWER BI",  "fill": "FBE9E7", "font": "BF360C", "stage": 6},
    "script":    {"label": "SCRIPT",    "fill": "F5F5F5", "font": "424242", "stage": 3},
    "function":  {"label": "FUNCTION",  "fill": "FFF3E0", "font": "E65100", "stage": 3},
    "unknown":   {"label": "OBJECT",    "fill": "EEEEEE", "font": "616161", "stage": 1},
}

STAGE_META = {
    1: {"name": "Source Tables",          "fill": "DDEEFF", "font": "1F4E79"},
    2: {"name": "Views / Interface",      "fill": "E8F5E9", "font": "1B5E20"},
    3: {"name": "Stored Procs / Scripts", "fill": "FFF9C4", "font": "F57F17"},
    4: {"name": "SSIS Packages",          "fill": "FCE4EC", "font": "880E4F"},
    5: {"name": "SSAS / OLAP",            "fill": "F3E5F5", "font": "4A148C"},
    6: {"name": "Reports & Consumers",    "fill": "E0F7FA", "font": "006064"},
}

# ── Normalisation ─────────────────────────────────────────────────────────────
def _norm(s): return re.sub(r'[\[\]\s]', '', s).lower()
def _short(s):
    p = _norm(s).split('.')
    return p[-1] if p else s

SKIP_PARTS = {'obj','bin','node_modules','.git','packages','debug','release'}
SQL_KEYWORDS = {'sys.','information_schema.','tempdb.','#','##',
                'inserted.','deleted.','openjson(','string_split('}

def _filter(names):
    return [n for n in names
            if '.' in n and not any(n.startswith(k) for k in SQL_KEYWORDS)
            and len(n) > 3]

# ── Regexes ───────────────────────────────────────────────────────────────────
R_FROM    = re.compile(r'\bFROM\s+(\[?\w+\]?\.(?:\[?\w+\]?))', re.I)
R_JOIN    = re.compile(r'\bJOIN\s+(\[?\w+\]?\.(?:\[?\w+\]?))',  re.I)
R_INTO    = re.compile(r'\bINSERT\s+(?:INTO\s+)?(\[?\w+\]?\.(?:\[?\w+\]?))', re.I)
R_UPDATE  = re.compile(r'\bUPDATE\s+(\[?\w+\]?\.(?:\[?\w+\]?))', re.I)
R_MERGE   = re.compile(r'\bMERGE\s+(?:INTO\s+)?(\[?\w+\]?\.(?:\[?\w+\]?))', re.I)
R_EXEC    = re.compile(r'\bEXEC(?:UTE)?\s+(\[?\w+\]?(?:\.(?:\[?\w+\]?))?)\s', re.I)
R_PROC    = re.compile(r'\bCREATE\s+(?:OR\s+ALTER\s+)?(?:PROCEDURE|PROC)\s+(\[?\w+\]?(?:\.(?:\[?\w+\]?))?)', re.I)
R_VIEW    = re.compile(r'\bCREATE\s+(?:OR\s+ALTER\s+)?VIEW\s+(\[?\w+\]?(?:\.(?:\[?\w+\]?))?)', re.I)
R_TABLE   = re.compile(r'\bCREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\[?\w+\]?(?:\.(?:\[?\w+\]?))?)', re.I)
R_FUNC    = re.compile(r'\bCREATE\s+(?:OR\s+ALTER\s+)?FUNCTION\s+(\[?\w+\]?(?:\.(?:\[?\w+\]?))?)', re.I)

def _strip(text):
    text = re.sub(r'--[^\n]*', ' ', text)
    return re.sub(r'/\*.*?\*/', ' ', text, flags=re.DOTALL)

def _infer_type(name, hint='unknown'):
    n = name.lower()
    if hint != 'unknown': return hint
    if any(x in n for x in ('_report','_rpt','.rdl')): return 'ssrs'
    if '.pbix' in n or 'powerbi' in n or 'power_bi' in n: return 'powerbi'
    if any(x in n for x in ('.bim','ssas','cube','_cube')): return 'ssas'
    if any(x in n for x in ('.dtsx','ssis','dwh_','_input_','_load_')): return 'ssis'
    if any(x in n for x in ('usp_','sp_','proc_')): return 'procedure'
    if n.startswith('v_') or n.startswith('vw_'): return 'view'
    return 'unknown'

# ── Parsers ───────────────────────────────────────────────────────────────────
def _parse_sql(path):
    try: raw = path.read_text(encoding='utf-8', errors='ignore')
    except: return None
    text = _strip(raw)
    obj_name, obj_type = path.stem.lower(), 'script'
    for regex, otype in [(R_PROC,'procedure'),(R_VIEW,'view'),
                          (R_FUNC,'function'),(R_TABLE,'table')]:
        m = regex.search(text)
        if m:
            obj_name = _norm(m.group(1))
            obj_type = otype
            break
    sources = _filter([_norm(m.group(1)) for m in R_FROM.finditer(text)] +
                      [_norm(m.group(1)) for m in R_JOIN.finditer(text)])
    targets = _filter([_norm(m.group(1)) for m in R_INTO.finditer(text)] +
                      [_norm(m.group(1)) for m in R_UPDATE.finditer(text)] +
                      [_norm(m.group(1)) for m in R_MERGE.finditer(text)])
    execs   = [_norm(m.group(1)) for m in R_EXEC.finditer(text)
               if '.' in m.group(1)]
    return {'name': obj_name, 'type': obj_type, 'file': str(path),
            'sources': list(set(sources)-{obj_name}),
            'targets': list(set(targets)-{obj_name}),
            'execs':   list(set(execs)-{obj_name})}

def _parse_dtsx(path):
    try: raw = path.read_text(encoding='utf-8', errors='ignore')
    except: return None
    sources, targets = [], []
    for block in re.findall(r'<(?:\w+:)?SqlCommand[^>]*>(.*?)</(?:\w+:)?SqlCommand>',
                             raw, re.DOTALL|re.I):
        t = _strip(block)
        sources += _filter([_norm(m.group(1)) for m in R_FROM.finditer(t)] +
                           [_norm(m.group(1)) for m in R_JOIN.finditer(t)])
        targets += _filter([_norm(m.group(1)) for m in R_INTO.finditer(t)])
    for ref in re.findall(r'(?:OpenRowset|TableName|TableOrViewName)\s*=\s*"([^"]+)"',
                           raw, re.I):
        n = _norm(ref)
        if '.' in n: sources.append(n)
    return {'name': path.stem.lower(), 'type': 'ssis', 'file': str(path),
            'sources': list(set(sources)), 'targets': list(set(targets)),
            'execs': []}

def _parse_bim(path):
    try: data = json.loads(path.read_text(encoding='utf-8', errors='ignore'))
    except: return None
    sources = []
    def _walk(n):
        if isinstance(n, dict):
            for k,v in n.items():
                if k.lower() in ('query','expression','commandtext'):
                    t = _strip(str(v))
                    sources.extend(_filter(
                        [_norm(m.group(1)) for m in R_FROM.finditer(t)] +
                        [_norm(m.group(1)) for m in R_JOIN.finditer(t)]))
                _walk(v)
        elif isinstance(n, list):
            for i in n: _walk(i)
    _walk(data)
    return {'name': path.stem.lower(), 'type': 'ssas', 'file': str(path),
            'sources': list(set(sources)), 'targets': [], 'execs': []}

def _parse_rdl(path):
    try: raw = path.read_text(encoding='utf-8', errors='ignore')
    except: return None
    sources = []
    for block in re.findall(r'<CommandText[^>]*>(.*?)</CommandText>',
                             raw, re.DOTALL|re.I):
        t = _strip(block)
        sources.extend(_filter(
            [_norm(m.group(1)) for m in R_FROM.finditer(t)] +
            [_norm(m.group(1)) for m in R_JOIN.finditer(t)]))
    return {'name': path.stem.lower(), 'type': 'ssrs', 'file': str(path),
            'sources': list(set(sources)), 'targets': [], 'execs': []}

# ── Graph ─────────────────────────────────────────────────────────────────────
class Graph:
    def __init__(self):
        self.objects    = {}
        self.downstream = defaultdict(set)
        self.upstream   = defaultdict(set)
        self.evidence   = defaultdict(lambda: defaultdict(list))

    def add(self, obj):
        if obj and obj.get('name'):
            self.objects[obj['name']] = obj

    def build(self):
        for obj in self.objects.values():
            n = obj['name']
            for s in obj.get('sources',[]): self._edge(s, n, obj['file'])
            for t in obj.get('targets',[]): self._edge(n, t, obj['file'])
            for e in obj.get('execs',  []): self._edge(n, e, obj['file'])

    def _edge(self, src, tgt, f):
        if src == tgt: return
        self.downstream[src].add(tgt)
        self.upstream[tgt].add(src)
        self.evidence[src][tgt].append(Path(f).name)

    def bfs(self, start, direction='downstream', depth=12):
        graph = self.downstream if direction=='downstream' else self.upstream
        visited, result = set(), []
        q = deque([(start, 0)])
        while q:
            cur, d = q.popleft()
            if d >= depth: continue
            for nb in graph.get(cur, []):
                if nb not in visited:
                    visited.add(nb)
                    obj  = self.objects.get(nb, {})
                    otype = obj.get('type', _infer_type(nb))
                    files = self.evidence.get(
                        cur if direction=='downstream' else nb,{}).get(
                        nb  if direction=='downstream' else cur,[])
                    result.append({
                        'name':   nb,
                        'short':  _short(nb),
                        'type':   otype,
                        'depth':  d+1,
                        'parent': cur,
                        'files':  list(set(files))[:2],
                        'dir':    direction,
                    })
                    q.append((nb, d+1))
        return result

# ── Scan ─────────────────────────────────────────────────────────────────────
def scan(repo: Path) -> Graph:
    g = Graph()
    skip = SKIP_PARTS
    parsers = {'.sql':_parse_sql,'.dtsx':_parse_dtsx,
               '.bim':_parse_bim, '.rdl':_parse_rdl}
    counts = defaultdict(int)
    for ext, fn in parsers.items():
        for fp in repo.rglob(f'*{ext}'):
            if any(p in fp.parts for p in skip): continue
            obj = fn(fp)
            if obj: g.add(obj); counts[ext]+=1
    g.build()
    print(f"  Scanned: {sum(counts.values())} files — "
          + ", ".join(f"{v} {k}" for k,v in counts.items() if v))
    return g

# ── Excel visual builder ──────────────────────────────────────────────────────
def _f(hex_): return PatternFill("solid", fgColor=hex_)
def _font(color="000000", bold=False, sz=9, name="Calibri"):
    return Font(name=name, bold=bold, color=color, size=sz)
def _border(color="BBBBBB"):
    s = Side(style='thin', color=color)
    return Border(left=s,right=s,top=s,bottom=s)
def _align(h='center'):
    return Alignment(horizontal=h, vertical='center', wrap_text=True)

# Each "box" occupies a fixed cell grid:
BOX_H = 3      # rows tall per box
BOX_W = 4      # columns wide per box
GAP_C = 2      # columns for arrow gap between stages
GAP_R = 1      # rows gap between boxes in same stage

def _draw_box(ws, row, col, label, type_key, is_target=False):
    """Draw a coloured merged-cell box for one object."""
    meta  = TYPES.get(type_key, TYPES['unknown'])
    fill  = "FFD700" if is_target else meta['fill']   # gold for target obj
    font_c= "000000" if is_target else meta['font']
    border_c = "999999" if not is_target else "B8860B"

    # Merge the box cells
    end_row = row + BOX_H - 1
    end_col = col + BOX_W - 1
    ws.merge_cells(start_row=row,   start_column=col,
                   end_row=end_row, end_column=end_col)
    cell = ws.cell(row=row, column=col)

    # Type badge on first line, name on second
    display = f"[ {meta['label']} ]\n{label}"
    cell.value     = display
    cell.fill      = _f(fill)
    cell.font      = Font(name="Calibri", bold=True,
                          color=font_c, size=8)
    cell.alignment = Alignment(horizontal='center', vertical='center',
                               wrap_text=True)

    # Apply border to all cells in merged region
    bdr = Border(
        left   = Side(style='medium' if is_target else 'thin',
                      color=border_c),
        right  = Side(style='medium' if is_target else 'thin',
                      color=border_c),
        top    = Side(style='medium' if is_target else 'thin',
                      color=border_c),
        bottom = Side(style='medium' if is_target else 'thin',
                      color=border_c),
    )
    for r in range(row, end_row+1):
        for c in range(col, end_col+1):
            ws.cell(row=r, column=c).border = bdr

def _draw_arrow(ws, row, col):
    """Draw a simple → arrow in the gap column."""
    mid_row = row + BOX_H // 2
    cell = ws.cell(row=mid_row, column=col)
    cell.value     = "→"
    cell.font      = Font(name="Calibri", bold=True, color="888888", size=14)
    cell.alignment = _align('center')

def _stage_header(ws, row, col, width_cols, stage_key):
    """Draw a stage header bar across the stage's columns."""
    meta = STAGE_META.get(stage_key, {"name":"","fill":"EEEEEE","font":"333333"})
    end_col = col + width_cols - 1
    ws.merge_cells(start_row=row, start_column=col,
                   end_row=row,   end_column=end_col)
    cell = ws.cell(row=row, column=col)
    cell.value     = meta['name']
    cell.fill      = _f(meta['fill'])
    cell.font      = Font(name="Calibri", bold=True,
                          color=meta['font'], size=9)
    cell.alignment = _align('center')
    ws.row_dimensions[row].height = 18

def write_excel(target_name: str, graph: Graph,
                upstream: list, downstream: list, out: Path):

    wb = openpyxl.Workbook()

    # ── SHEET 1: VISUAL FLOW ─────────────────────────────────────────────────
    ws = wb.active
    ws.title = "📊 Lineage Flow"
    ws.sheet_view.showGridLines = False

    # --- Layout strategy ---
    # Columns:  [UPSTREAM objects] ... [TARGET] ... [DOWNSTREAM objects]
    # Each object column-band = BOX_W cols + GAP_C cols (for arrow)
    # We bucket upstream/downstream by depth then lay out left→right

    # Bucket by depth
    up_by_depth   = defaultdict(list)
    down_by_depth = defaultdict(list)
    for obj in upstream:   up_by_depth[obj['depth']].append(obj)
    for obj in downstream: down_by_depth[obj['depth']].append(obj)

    max_up   = max(up_by_depth.keys(),   default=0)
    max_down = max(down_by_depth.keys(), default=0)

    # Column layout: upstream stages run right-to-left from target
    # downstream stages run left-to-right from target
    # Target sits in the middle

    TITLE_ROWS   = 4   # top title + legend rows
    HEADER_ROW   = TITLE_ROWS + 1
    DATA_START   = HEADER_ROW + 2

    # Each depth = BOX_W + GAP_C columns
    BAND = BOX_W + GAP_C

    # Calculate starting column for target
    target_col = 1 + max_up * BAND + (GAP_C if max_up > 0 else 0)

    # ── Title ──
    ws.merge_cells(f'A1:{get_column_letter(target_col + max_down*BAND + BOX_W)}1')
    title_cell = ws['A1']
    title_cell.value     = f"SQL Object Lineage — {_short(target_name).upper()}"
    title_cell.fill      = _f("1F4E79")
    title_cell.font      = Font(name="Calibri", bold=True, color="FFFFFF", size=13)
    title_cell.alignment = _align('center')
    ws.row_dimensions[1].height = 28

    # ── Sub-title ──
    ws.merge_cells(f'A2:{get_column_letter(target_col + max_down*BAND + BOX_W)}2')
    sub = ws['A2']
    sub.value     = (f"Full object: {target_name}  |  "
                     f"Upstream objects: {len(upstream)}  |  "
                     f"Downstream objects: {len(downstream)}  |  "
                     f"Generated: {datetime.now().strftime('%d %b %Y %H:%M')}")
    sub.fill      = _f("2E75B6")
    sub.font      = Font(name="Calibri", bold=False, color="FFFFFF", size=8)
    sub.alignment = _align('center')
    ws.row_dimensions[2].height = 14

    # ── Legend ──
    leg_col = 1
    ws.row_dimensions[3].height = 6   # spacer
    ws.row_dimensions[4].height = 18
    for tkey, tmeta in list(TYPES.items())[:7]:
        ws.merge_cells(start_row=4, start_column=leg_col,
                       end_row=4,   end_column=leg_col+1)
        lc = ws.cell(row=4, column=leg_col)
        lc.value     = tmeta['label']
        lc.fill      = _f(tmeta['fill'])
        lc.font      = Font(name="Calibri", bold=True,
                            color=tmeta['font'], size=8)
        lc.alignment = _align('center')
        lc.border    = _border(tmeta['font'])
        leg_col += 3

    # ── Target box ──
    target_type = graph.objects.get(target_name, {}).get('type',
                   _infer_type(target_name))
    target_row  = DATA_START + 2   # vertically centred
    _draw_box(ws, target_row, target_col,
              _short(target_name), target_type, is_target=True)

    # ── Upstream boxes (right-to-left from target) ──
    for depth in range(1, max_up+1):
        objs = up_by_depth[depth]
        col  = target_col - depth * BAND
        if col < 1: col = 1

        # Stage header
        stage_key = TYPES.get(objs[0]['type'] if objs else 'unknown',
                               TYPES['unknown'])['stage']
        _stage_header(ws, DATA_START, col, BOX_W, stage_key)

        for i, obj in enumerate(objs):
            row = DATA_START + 2 + i * (BOX_H + GAP_R)
            _draw_box(ws, row, col, obj['short'], obj['type'])
            # Arrow →  (in gap columns between this box and next)
            if depth < max_up:
                _draw_arrow(ws, row, col + BOX_W)
            else:
                # Arrow pointing to target
                _draw_arrow(ws, row, col + BOX_W)

    # ── Downstream boxes (left-to-right from target) ──
    for depth in range(1, max_down+1):
        objs = down_by_depth[depth]
        col  = target_col + BOX_W + GAP_C + (depth-1) * BAND

        stage_key = TYPES.get(objs[0]['type'] if objs else 'unknown',
                               TYPES['unknown'])['stage']
        _stage_header(ws, DATA_START, col, BOX_W, stage_key)

        # Arrow from previous column to this one
        arr_col = col - GAP_C
        for i, obj in enumerate(objs):
            row = DATA_START + 2 + i * (BOX_H + GAP_R)
            _draw_box(ws, row, col, obj['short'], obj['type'])
            _draw_arrow(ws, row, col - GAP_C)

    # ── Set column widths ──
    total_cols = target_col + max_down * BAND + BOX_W + 2
    for c in range(1, total_cols+1):
        # Gap columns are narrow (arrow), box columns wider
        col_in_band = (c - 1) % BAND
        if col_in_band >= BOX_W:   # gap column
            ws.column_dimensions[get_column_letter(c)].width = 4
        else:                       # box column
            ws.column_dimensions[get_column_letter(c)].width = 11

    # ── Row heights ──
    for r in range(DATA_START+2, DATA_START + 2 +
                   max(len(upstream), len(downstream), 1) *
                   (BOX_H + GAP_R) + 4):
        ws.row_dimensions[r].height = 20

    # ── SHEET 2: UPSTREAM TABLE ───────────────────────────────────────────────
    ws2 = wb.create_sheet("⬆ Upstream Detail")
    ws2.sheet_view.showGridLines = False
    _table_sheet(ws2, f"Upstream — objects feeding into: {target_name}",
                 upstream, "1B5E20", "E8F5E9")

    # ── SHEET 3: DOWNSTREAM TABLE ─────────────────────────────────────────────
    ws3 = wb.create_sheet("⬇ Downstream Detail")
    ws3.sheet_view.showGridLines = False
    _table_sheet(ws3, f"Downstream — objects fed by: {target_name}",
                 downstream, "880E4F", "FCE4EC")

    # ── SHEET 4: FULL EDGE LIST ───────────────────────────────────────────────
    ws4 = wb.create_sheet("📋 All Edges")
    ws4.sheet_view.showGridLines = False
    all_rows = ([{**r,'dir':'UPSTREAM'}   for r in upstream] +
                [{**r,'dir':'DOWNSTREAM'} for r in downstream])
    _table_sheet(ws4, f"All lineage edges for: {target_name}",
                 all_rows, "1F4E79", "DDEEFF", show_dir=True)

    wb.save(str(out))
    print(f"  Excel saved → {out}")

def _table_sheet(ws, title, rows, hdr_color, alt_color, show_dir=False):
    """Write a clean formatted table to a sheet."""
    # Title
    ws.merge_cells('A1:G1')
    ws['A1'].value     = title
    ws['A1'].fill      = PatternFill("solid", fgColor=hdr_color)
    ws['A1'].font      = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 26

    headers = (["Direction"] if show_dir else []) + [
        "Object Name", "Short Name", "Type", "Depth",
        "Parent Object", "Via File(s)"]
    fills   = [hdr_color] * len(headers)

    # Header row
    for ci, (h, fc) in enumerate(zip(headers, fills), 1):
        cell = ws.cell(row=2, column=ci, value=h)
        cell.fill      = PatternFill("solid", fgColor=fc)
        cell.font      = Font(name="Calibri", bold=True, color="FFFFFF", size=9)
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border    = _border()
    ws.row_dimensions[2].height = 18

    for ri, row in enumerate(
            sorted(rows, key=lambda r: (r.get('depth',0), r.get('name',''))), 3):
        bg = alt_color if ri % 2 == 0 else "FFFFFF"
        otype = row.get('type','unknown')
        tmeta = TYPES.get(otype, TYPES['unknown'])

        vals = (([row.get('dir','')]  if show_dir else []) + [
            row.get('name',''),
            row.get('short', _short(row.get('name',''))),
            tmeta['label'],
            row.get('depth',''),
            row.get('parent',''),
            '; '.join(row.get('files',[]))
        ])
        for ci, val in enumerate(vals, 1):
            cell = ws.cell(row=ri, column=ci, value=val)
            # Type column gets object-type colour
            if (show_dir and ci==4) or (not show_dir and ci==3):
                cell.fill = PatternFill("solid", fgColor=tmeta['fill'])
                cell.font = Font(name="Calibri", bold=True,
                                 color=tmeta['font'], size=9)
            else:
                cell.fill = PatternFill("solid", fgColor=bg)
                cell.font = Font(name="Calibri", bold=False,
                                 color="333333", size=9)
            cell.alignment = Alignment(horizontal='left', vertical='center',
                                       wrap_text=True)
            cell.border = _border()
        ws.row_dimensions[ri].height = 16

    # Column widths
    widths = ([14] if show_dir else []) + [48,22,12,8,40,36]
    for ci, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.freeze_panes = "A3"

# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(
        description="Talbot BI — SQL Object Lineage (Visual Excel)")
    ap.add_argument('--object', required=True,
        help='Object name, e.g. "dbo.Claims" or "usp_LoadClaims"')
    ap.add_argument('--repo',   default='.',
        help='Repo root path (default: current directory)')
    ap.add_argument('--out',    default=None,
        help='Output Excel path')
    ap.add_argument('--depth',  type=int, default=12,
        help='Max lineage depth (default 12)')
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    print(f"\nTalbot BI — SQL Object Lineage Scanner")
    print(f"  Target : {args.object}")
    print(f"  Repo   : {repo}\n  Scanning...")

    graph  = scan(repo)
    target = _norm(args.object)

    if target not in graph.objects:
        candidates = [k for k in graph.objects
                      if target in k or k.endswith(target.split('.')[-1])]
        if candidates:
            target = sorted(candidates)[0]
            print(f"  Resolved → {target}")
        else:
            print(f"  ⚠ '{args.object}' not found — running lineage anyway.")

    up   = graph.bfs(target, 'upstream',   args.depth)
    down = graph.bfs(target, 'downstream', args.depth)
    print(f"  Upstream:   {len(up)}")
    print(f"  Downstream: {len(down)}")

    safe   = target.replace('.','_').replace('/','_')
    out    = Path(args.out) if args.out else Path(f"lineage_{safe}.xlsx")
    write_excel(target, graph, up, down, out)
    print(f"\n✅ Done — open: {out}\n")

if __name__ == '__main__':
    main()
