# Tier 1 Branch Health Metrics Skill

## Quick Start

This skill analyzes git repositories and generates **Tier 1 branch health reports** covering:
- Branch divergence from main (commits behind/ahead)
- Branch staleness (days since last commit)
- Active vs. stale branch ratio
- Health classification for each branch

### Usage

Simply ask Claude with a GitHub repository URL:

```
Analyze branch health for https://github.com/myorg/myrepo
```

Or:

```
Generate a Tier 1 branch health report for https://github.com/myorg/myrepo.git
```

**Optional:** Set a GitHub token for higher API rate limits and private repo access:

```bash
export GITHUB_TOKEN=ghp_your_token_here
```

---

## What's Included

### Files

```
tier1-branch-health/
├── SKILL.md                      # Skill definition and documentation
├── README.md                     # This file
└── scripts/
    └── analyze_branches.py       # Main analyzer script
```

### Output Formats

The skill produces reports in two formats:

1. **Human-readable text** (default)
   ```
   📊 SUMMARY DASHBOARD
   - Total branches, active ratio, health score
   
   📋 BRANCH INVENTORY
   - Table with branch age, divergence, status, actions
   
   💡 RECOMMENDATIONS
   - Actionable next steps
   ```

2. **JSON** (for CI/CD integration)
   ```json
   {
     "total_branches": 12,
     "active_branches": 8,
     "stale_branches": 2,
     "active_ratio": 66.7,
     "health_score": 8.5,
     "branches": { ... }
   }
   ```

---

## Report Metrics Explained

### 1. **Total Branches**
Count of all local branches in the repository.

### 2. **Active Branches**
Number of branches with commits in the last 30 days.

### 3. **Stale Branches**
Number of branches untouched for >60 days (archive candidates).

### 4. **Active Ratio**
Percentage of branches with recent activity.
- ✓ >70% = healthy hygiene
- ⚠ 50–70% = monitor and plan cleanup
- ✗ <50% = poor hygiene, cleanup needed

### 5. **Branch Status Classification**

Each branch is classified as:

- **main** — The primary branch (typically `main` or `master`)
- **✓ healthy** — <7 days old, <15 commits behind main
- **⚠ monitor** — 7–30 days old OR 15–30 commits behind
- **✗ diverged** — >60 commits behind main (high merge conflict risk)
- **✗ stale** — >60 days without activity (archive candidate)

### 6. **Divergence (Behind-Ahead)**

- **Behind**: Commits on main that aren't on this branch
- **Ahead**: Commits on this branch that aren't on main
- Helps identify branches that need rebasing or are ready to merge

### 7. **Health Score**
Overall repo health on a 0–10 scale:
- 10: Perfect (all active, no stale branches, no divergence)
- 8–9: Good (most branches current, minor cleanup needed)
- 6–7: Acceptable (some stale branches, monitor divergence)
- <6: Poor (significant hygiene issues, cleanup required)

---

## Sample Output

```
================================================================================
TIER 1 BRANCH HEALTH REPORT
================================================================================

📊 SUMMARY DASHBOARD
────────────────────────────────────────────────────────────────────────────────
Total Branches:        12
Active (last 30d):     8 (66.7%)
Stale (>60d):          2
Avg Staleness:         18.4 days
Avg Divergence:        8.2 commits behind main
Health Score:          8.2/10

📋 BRANCH INVENTORY
────────────────────────────────────────────────────────────────────────────────
Branch                         Age      Behind   Status       Action
────────────────────────────────────────────────────────────────────────────────
main                           0        0        ✓ MAIN       
feature/auth                   2        2        ✓ HEALTHY    Merge soon
feature/dashboard              5        4        ✓ HEALTHY    
release/v1.5                   22       8        ✓ HEALTHY    
feature/api-v2                 35       18       ⚠ MONITOR    Rebase in 2w
release/v1.4                   45       22       ⚠ MONITOR    Rebase in 2w
feature/legacy-ui              62       35       ✗ DIVERGED   High conflict risk
chore/old-deps                 90       42       ✗ STALE      Archive or decide
experimental/new-framework     95       50       ✗ STALE      Archive or decide

💡 RECOMMENDATIONS
────────────────────────────────────────────────────────────────────────────────
1. Archive 2 stale branch(es): chore/old-deps, experimental/new-framework
2. Review 1 diverged branch(es) for conflicts: feature/legacy-ui
3. Rebase/merge 2 monitoring branch(es) within 2 weeks
4. Merge 2 ready-to-merge branch(es)
⚠️  Monitor repository hygiene; 67% active is healthy but watch for drift.

================================================================================
```

---

## How It Works

### GitHub API (No Local Clone Required)

The script uses GitHub's REST API:
- `GET /repos/{owner}/{repo}/branches` — List all branches
- `GET /repos/{owner}/{repo}/compare/{main}...{branch}` — Calculate divergence

Works with:
- ✓ Public repositories (no auth needed)
- ✓ Private repositories (requires GitHub token)
- ✓ Any repository size (no cloning overhead)
- ✗ Local repositories (use GitHub URLs instead)

### Performance

- Most repos: 2–10 seconds (API-bound, not git-bound)
- Large repos (1000+ branches): 10–30 seconds
- API rate limits: 60/hour (unauthenticated) or 5,000/hour (authenticated)

---

## Customization

Ask Claude to adjust thresholds:

```
Analyze branch health for https://github.com/owner/repo
- Main branch: develop (not main)
- Stale threshold: 90 days (not 60)
- Divergence alert: 40 commits (not 60)
- Output: JSON (not text)
```

Supported options:
- `main_branch`: Override auto-detected main branch (e.g., `trunk`, `develop`)
- `stale_threshold_days`: Days until a branch is "stale" (default: 60)
- `divergence_alert_commits`: Commits behind to trigger "diverged" (default: 60)
- `output_format`: `text` or `json`

---

## Integration Ideas

### Continuous Monitoring

Create a GitHub Actions workflow to run weekly:

```yaml
name: Branch Health Check
on:
  schedule:
    - cron: '0 9 * * 1' # Weekly Monday 9 AM
jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
        with:
          fetch-depth: 0
      - run: python analyze_branches.py . --json > health_report.json
      - uses: actions/upload-artifact@v3
        with:
          name: branch-health-report
          path: health_report.json
```

### Slack Notifications

Extend the script to post alerts to Slack:
```json
{
  "blocks": [
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": "*Branch Health Alert*\n4 stale branches detected\n2 branches >60 commits behind"
      }
    }
  ]
}
```

### Automated Cleanup

Use the JSON output to auto-delete stale branches:
```bash
stale=$(python analyze_branches.py . --json | jq -r '.branches[] | select(.status=="stale") | .name')
for branch in $stale; do
  git push origin --delete $branch
done
```

---

## Troubleshooting

### "API rate limit exceeded"
```
✗ GitHub API rate limit exceeded. Use authentication for higher limits: export GITHUB_TOKEN=<your_token>
```
**Solution:** Create a GitHub personal access token and set the environment variable:
```bash
export GITHUB_TOKEN=ghp_xxxxxxxxxxxxx
```
Rate limits: 60 requests/hour (unauthenticated) → 5,000 requests/hour (authenticated)

### "Repository not found"
```
✗ Error: Repository not found
```
**Solution:** Verify the repository URL is correct and public (or use auth token for private repos).

### "No branches found"
```
✗ Error: No branches found or repository not accessible
```
**Solution:** 
- Check the GitHub URL is correct
- Ensure you have access (use GITHUB_TOKEN for private repos)
- Verify the repository exists

### Main branch not detected
```
📌 Main branch: main (but you expected develop)
```
**Solution:** Specify the main branch explicitly:
```
Analyze https://github.com/owner/repo with main_branch=develop
```

---

## Tier 1 Focus

This skill focuses on the **high-impact, low-maintenance metrics**:

✓ Fully automated (no manual effort)
✓ No external API calls (uses local git only)
✓ Scales to any repo size
✓ Actionable (clear next steps)
✓ <30 second runtime

For more advanced tracking, see **Tier 2 skills** (code review turnaround, long-lived branches, deployment readiness).

---

## License & Support

This skill is part of the **GitHub Branch Health Metrics Framework** by [Aziz].

For questions or improvements, reach out with:
- Specific use cases (org size, team, workflow)
- Performance issues
- Metric suggestions

Happy branch gardening! 🌿
