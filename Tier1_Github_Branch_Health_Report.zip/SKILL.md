---
name: tier1-branch-health
description: Generate a comprehensive Tier 1 branch health report for a git repository. Analyze branch divergence from main, staleness, active vs. stale ratios, and basic merge readiness. Use this whenever you need to assess repository branch hygiene, identify stale branches, or track how in-sync feature branches are with the main branch. Useful for DevOps teams, release engineering, and code governance.
---

# Tier 1 Branch Health Metrics Skill

## Overview

This skill analyzes a git repository and generates a **Tier 1 branch health report** covering:

1. **Branch Divergence** — commits ahead/behind main per branch
2. **Branch Staleness** — days since last commit per branch
3. **Active vs. Stale Ratio** — % of branches with recent activity
4. **Branch Status Summary** — categorizes branches as healthy, stale, or diverged

All metrics are calculated locally from git history—no external API calls or authentication required.

---

## How to Use

### Input

Provide a path to a git repository:
- **Local path**: `/path/to/repo` or `/home/user/project`
- **Cloned repo URL**: Will be cloned to a temp directory automatically if you have git access
- **Current working directory**: `.` if you're already in the repo

### Output

A formatted HTML/text report with:
- Summary dashboard (key metrics at a glance)
- Branch inventory table (sorted by health status)
- Actionable recommendations (e.g., branches to archive, PR blockers)

---

## Metrics Explained

### 1. Branch Divergence (Commits Behind-Ahead)

**What it measures**: How many commits separate a branch from main in each direction.

**Formula**:
- **Behind**: `git rev-list --count main..{branch}`
- **Ahead**: `git rev-list --count {branch}..main`

**Healthy threshold**:
- Feature branches: ≤15 commits behind (ready to merge)
- Release branches: ≤30 commits behind (acceptable for release prep)
- Divergence >60: Archive candidate

### 2. Branch Staleness (Days Since Last Commit)

**What it measures**: Age of the most recent commit on each branch.

**Formula**: `(today - branch_last_commit_date) in days`

**Healthy threshold**:
- Active development: <7 days
- Release/maintenance: <30 days
- Archive if: >60 days without activity

### 3. Active vs. Stale Ratio

**What it measures**: % of branches with commits in the last 30 days.

**Formula**: `(branches_with_commits_in_30d / total_branches) × 100`

**Healthy threshold**:
- >70% active = good hygiene
- 50–70% = monitor, consider cleanup
- <50% = poor hygiene, scheduled cleanup needed

---

## Running the Skill

### Step 1: Provide Repository Path

Tell Claude:
```
Analyze branch health for /path/to/my/repo
```

or:

```
Generate a Tier 1 branch health report for https://github.com/user/repo.git
```

### Step 2: Claude Generates Report

The skill will:
1. Clone the repo (if URL) or navigate to local path
2. Fetch all branches and main metadata
3. Calculate divergence, staleness, and activity ratios
4. Classify each branch (Healthy / Monitor / Stale / Diverged)
5. Generate a formatted report

### Step 3: Review & Act

- **Healthy branches**: No action needed
- **Monitor branches**: Consider rebasing or merging within 2 weeks
- **Stale branches** (>60 days): Schedule for archival or decision
- **Diverged branches** (>60 commits behind): Likely merge conflict risk; prioritize review

---

## Report Structure

### Dashboard Summary
```
Total Branches: 24
Active (last 30d): 16 (66%)
Stale (>60d): 4 (17%)
Avg Staleness: 18 days
Avg Divergence (behind): 12 commits

Health Score: 7.2/10
  ✓ Most branches current
  ⚠ 4 branches stale; recommend archival
  ⚠ 1 branch >60 commits behind
```

### Branch Inventory Table
| Branch | Days Old | Behind | Ahead | Status | Action |
|--------|----------|--------|-------|--------|--------|
| main | 0 | 0 | 0 | ✓ Healthy | — |
| feature/auth | 3 | 2 | 0 | ✓ Healthy | Merge soon |
| release/v2.1 | 28 | 12 | 0 | ✓ Monitor | Rebase within 2w |
| feature/old-ui | 95 | 45 | 0 | ✗ Stale | Archive or decide |

### Recommendations
1. **Archive 4 stale branches** — >60 days without activity
2. **Rebase 3 monitor branches** — catching up with main
3. **Review 1 diverged branch** — >60 commits behind; high conflict risk
4. **Merge 5 ready-to-merge branches** — ≤7 days old, <5 commits behind

---

## Implementation Details

### Git Commands Used

```bash
# Fetch all branches (local + remote)
git fetch --all --prune

# Get all branch names
git for-each-ref --sort=-committerdate --format='%(refname:short)' refs/heads

# Divergence calculation
git rev-list --count main..{branch}    # commits ahead of main
git rev-list --count {branch}..main    # commits behind main

# Staleness (last commit timestamp)
git log -1 --format=%ai {branch}

# Branch list with last commit info
git branch -v
```

### Filtering

The report **excludes**:
- Detached HEAD (not a branch)
- Excluded branches (if specified): `main`, `master`, `develop`, `production`
- Branches <24 hours old (too recent to judge)

---

## Customization

You can refine the report by specifying:

1. **Custom main branch**:
   ```
   Main branch: trunk (instead of main/master)
   ```

2. **Thresholds**:
   ```
   Stale threshold: 90 days (instead of 60)
   Divergence alert: 40 commits (instead of 60)
   ```

3. **Excluded branches**:
   ```
   Ignore: staging, develop, hotfix/*
   ```

4. **Output format**:
   ```
   Output: CSV / JSON / Markdown table / HTML dashboard
   ```

---

## Examples

### Example 1: Small Team Repository
```
Input: ~/projects/myapp
Output: 8 branches, 75% active, avg staleness 12d
Action: No major issues; 1 branch ready to merge
```

### Example 2: Large Multi-Team Repository
```
Input: https://github.com/company/platform.git
Output: 124 branches, 52% active, avg staleness 35d
Action: Archive 18 stale branches; review 6 diverged branches
```

---

## Limitations & Notes

- **Git history required**: Works only with local git repos or publicly cloned repos
- **Private repos**: Clone manually or provide SSH key access
- **No PR API data**: Unmerged PR age calculated from git history only (less accurate than GitHub API)
- **Performance**: Large repos (>1000 branches) may take 30–60 seconds
- **Merge conflicts**: Detected via test merge; requires git >= 2.20

---

## Next Steps

After reviewing the report:

1. **Auto-archive**: Use the skill output to create a GitHub Actions cleanup workflow
2. **Monitor weekly**: Set up scheduled reports for ongoing health tracking
3. **Integrate with Tier 2**: Add code review turnaround, long-lived branch detection, and deployment readiness scores
