#!/usr/bin/env python3
"""
Tier 1 Branch Health Metrics Analyzer
Calculates: divergence, staleness, active ratio, merge readiness
"""

import subprocess
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Tuple
import sys

class BranchHealthAnalyzer:
    def __init__(self, repo_path: str, main_branch: str = None):
        self.repo_path = Path(repo_path)
        self.branches = {}
        self.errors = []
        
        # Verify repo exists
        if not (self.repo_path / ".git").exists():
            raise ValueError(f"Not a git repository: {repo_path}")
        
        # Auto-detect main branch if not specified
        if main_branch:
            self.main_branch = main_branch
        else:
            self.main_branch = self._detect_main_branch()
    
    def _detect_main_branch(self) -> str:
        """Detect main branch (main, master, trunk, etc)."""
        for candidate in ["main", "master", "trunk", "develop"]:
            output = self.run_git("rev-parse", "--verify", candidate)
            if output:
                return candidate
        return "main"  # Fallback
    
    def run_git(self, *args) -> str:
        """Execute git command and return output."""
        try:
            result = subprocess.run(
                ["git", "-C", str(self.repo_path)] + list(args),
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                self.errors.append(f"Git error: {result.stderr}")
                return ""
            return result.stdout.strip()
        except Exception as e:
            self.errors.append(f"Command failed: {e}")
            return ""
    
    def get_branches(self) -> List[str]:
        """Get all local branch names."""
        output = self.run_git("branch", "--format=%(refname:short)")
        if not output:
            return []
        
        branches = output.split("\n")
        # Filter out empty strings
        return [b.strip() for b in branches if b.strip()]
    
    def get_last_commit_date(self, branch: str) -> datetime:
        """Get last commit timestamp for a branch."""
        output = self.run_git("log", "-1", f"--format=%ai", branch)
        if not output:
            return datetime.now()
        
        try:
            # Format: 2024-01-15 10:30:45 +0000
            # Extract just the date and time part, ignore timezone
            date_time_str = output.split()[0] + " " + output.split()[1]
            return datetime.strptime(date_time_str, "%Y-%m-%d %H:%M:%S")
        except Exception as e:
            return datetime.now()
    
    def get_divergence(self, branch: str) -> Tuple[int, int]:
        """Get commits ahead and behind main."""
        try:
            # Ensure main branch exists
            main_check = self.run_git("rev-parse", f"--verify", self.main_branch)
            if not main_check:
                return 0, 0
            
            behind = self.run_git("rev-list", "--count", f"{self.main_branch}..{branch}")
            ahead = self.run_git("rev-list", "--count", f"{branch}..{self.main_branch}")
            
            return int(ahead or 0), int(behind or 0)
        except:
            return 0, 0
    
    def classify_branch(self, days_old: int, ahead: int, behind: int) -> str:
        """Classify branch health status."""
        # Exclude main branch
        if days_old == 0 and ahead == 0 and behind == 0:
            return "main"
        
        # Stale
        if days_old > 60:
            return "stale"
        
        # Diverged
        if behind > 60:
            return "diverged"
        
        # Monitor
        if days_old > 30 or behind > 30:
            return "monitor"
        
        # Healthy
        return "healthy"
    
    def analyze(self) -> Dict:
        """Run full analysis."""
        print("🔍 Scanning repository...", file=sys.stderr)
        
        # Get all branches
        branch_names = self.get_branches()
        if not branch_names:
            return {"error": "No branches found"}
        
        now = datetime.now()
        total = len(branch_names)
        active_count = 0
        stale_count = 0
        
        for idx, branch in enumerate(branch_names, 1):
            print(f"  [{idx}/{total}] Analyzing {branch}...", file=sys.stderr, end="\r")
            
            last_commit = self.get_last_commit_date(branch)
            days_old = (now - last_commit).days
            ahead, behind = self.get_divergence(branch)
            status = self.classify_branch(days_old, ahead, behind)
            
            self.branches[branch] = {
                "days_old": days_old,
                "last_commit": last_commit.isoformat(),
                "ahead": ahead,
                "behind": behind,
                "status": status,
            }
            
            if days_old <= 30:
                active_count += 1
            if days_old > 60:
                stale_count += 1
        
        print(" " * 60, file=sys.stderr, end="\r")  # Clear line
        
        # Calculate aggregate metrics
        active_ratio = (active_count / total * 100) if total > 0 else 0
        avg_staleness = sum(b["days_old"] for b in self.branches.values()) / total if total > 0 else 0
        avg_behind = sum(b["behind"] for b in self.branches.values()) / total if total > 0 else 0
        
        # Health score (0-10)
        health_score = 10.0
        if active_ratio < 50:
            health_score -= 3
        if stale_count > total * 0.2:
            health_score -= 2
        if any(b["behind"] > 60 for b in self.branches.values()):
            health_score -= 1
        
        return {
            "total_branches": total,
            "active_branches": active_count,
            "stale_branches": stale_count,
            "active_ratio": round(active_ratio, 1),
            "avg_staleness_days": round(avg_staleness, 1),
            "avg_divergence_behind": round(avg_behind, 1),
            "health_score": round(max(0, health_score), 1),
            "branches": self.branches,
            "errors": self.errors,
            "timestamp": datetime.now().isoformat(),
        }

def format_report(data: Dict) -> str:
    """Format analysis results as human-readable report."""
    if "error" in data:
        return f"❌ Error: {data['error']}"
    
    lines = []
    lines.append("=" * 80)
    lines.append("TIER 1 BRANCH HEALTH REPORT")
    lines.append("=" * 80)
    lines.append("")
    
    # Summary dashboard
    lines.append("📊 SUMMARY DASHBOARD")
    lines.append("-" * 80)
    lines.append(f"Total Branches:        {data['total_branches']}")
    lines.append(f"Active (last 30d):     {data['active_branches']} ({data['active_ratio']}%)")
    lines.append(f"Stale (>60d):          {data['stale_branches']}")
    lines.append(f"Avg Staleness:         {data['avg_staleness_days']} days")
    lines.append(f"Avg Divergence:        {data['avg_divergence_behind']} commits behind main")
    lines.append(f"Health Score:          {data['health_score']}/10")
    lines.append("")
    
    # Branch inventory
    lines.append("📋 BRANCH INVENTORY")
    lines.append("-" * 80)
    lines.append(f"{'Branch':<30} {'Age':<8} {'Behind':<8} {'Status':<12} {'Action'}")
    lines.append("-" * 80)
    
    # Sort branches by status priority
    status_order = {"healthy": 0, "monitor": 1, "diverged": 2, "stale": 3, "main": -1}
    sorted_branches = sorted(
        data['branches'].items(),
        key=lambda x: (status_order.get(x[1]['status'], 4), x[1]['days_old'])
    )
    
    for branch, info in sorted_branches:
        status = info['status'].upper()
        emoji = {
            "main": "✓",
            "healthy": "✓",
            "monitor": "⚠",
            "diverged": "✗",
            "stale": "✗",
        }.get(info['status'], "?")
        
        action = ""
        if info['status'] == "healthy" and info['days_old'] <= 7:
            action = "Merge soon"
        elif info['status'] == "monitor":
            action = "Rebase in 2w"
        elif info['status'] == "diverged":
            action = "High conflict risk"
        elif info['status'] == "stale":
            action = "Archive or decide"
        
        lines.append(
            f"{branch:<30} {info['days_old']:<8} {info['behind']:<8} "
            f"{emoji} {status:<10} {action}"
        )
    
    lines.append("")
    
    # Recommendations
    lines.append("💡 RECOMMENDATIONS")
    lines.append("-" * 80)
    
    stale = [b for b, info in data['branches'].items() if info['status'] == 'stale']
    diverged = [b for b, info in data['branches'].items() if info['status'] == 'diverged']
    monitor = [b for b, info in data['branches'].items() if info['status'] == 'monitor']
    
    if stale:
        lines.append(f"1. Archive {len(stale)} stale branch(es): {', '.join(stale[:3])}")
        if len(stale) > 3:
            lines.append(f"   ... and {len(stale) - 3} more")
    
    if diverged:
        lines.append(f"2. Review {len(diverged)} diverged branch(es) for conflicts: {', '.join(diverged[:3])}")
    
    if monitor:
        lines.append(f"3. Rebase/merge {len(monitor)} monitoring branch(es) within 2 weeks")
    
    healthy_ready = [
        b for b, info in data['branches'].items()
        if info['status'] == 'healthy' and info['days_old'] <= 7
    ]
    if healthy_ready:
        lines.append(f"4. Merge {len(healthy_ready)} ready-to-merge branch(es)")
    
    if data['active_ratio'] < 50:
        lines.append("⚠️  WARNING: Repository hygiene is poor. Consider scheduled cleanup.")
    
    lines.append("")
    lines.append("=" * 80)
    lines.append(f"Report generated: {data['timestamp']}")
    lines.append("=" * 80)
    
    return "\n".join(lines)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python analyze_branches.py <repo_path> [--json]")
        sys.exit(1)
    
    repo_path = sys.argv[1]
    output_json = "--json" in sys.argv
    
    try:
        analyzer = BranchHealthAnalyzer(repo_path)
        data = analyzer.analyze()
        
        if output_json:
            print(json.dumps(data, indent=2))
        else:
            print(format_report(data))
    
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)
