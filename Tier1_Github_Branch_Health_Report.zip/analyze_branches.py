#!/usr/bin/env python3
"""
Tier 1 Branch Health Metrics Analyzer
Uses GitHub API to analyze branch health
Calculates: divergence, staleness, active ratio, merge readiness
"""

import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import sys
import re
import os

class GitHubBranchAnalyzer:
    def __init__(self, repo_url: str, main_branch: str = None):
        self.repo_url = repo_url
        self.branches = {}
        self.errors = []
        self.api_base = "https://api.github.com"
        
        # Setup GitHub authentication if token available
        self.token = os.getenv("GITHUB_TOKEN")
        self.headers = {}
        if self.token:
            self.headers["Authorization"] = f"token {self.token}"
        
        # Parse GitHub URL
        self.owner, self.repo = self._parse_github_url(repo_url)
        if not self.owner or not self.repo:
            raise ValueError(f"Invalid GitHub URL: {repo_url}")
        
        # Auto-detect main branch if not specified
        if main_branch:
            self.main_branch = main_branch
        else:
            self.main_branch = self._detect_main_branch()
        
        print(f"📍 Repository: {self.owner}/{self.repo}", file=sys.stderr)
        print(f"📌 Main branch: {self.main_branch}", file=sys.stderr)
        if self.token:
            print("🔑 Using GitHub authentication", file=sys.stderr)
    
    def _parse_github_url(self, url: str) -> Tuple[str, str]:
        """Parse GitHub URL to extract owner and repo."""
        # Handle various GitHub URL formats
        patterns = [
            r"github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$",  # https://github.com/owner/repo.git
            r"github\.com/([^/]+)/([^/]+?)/?$",              # https://github.com/owner/repo
            r"github\.com:([^/]+)/([^/]+?)(?:\.git)?$",      # git@github.com:owner/repo.git
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1), match.group(2)
        
        return None, None
    
    def _api_request(self, endpoint: str) -> Dict:
        """Make API request to GitHub."""
        url = f"{self.api_base}{endpoint}"
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            
            if response.status_code == 404:
                self.errors.append(f"Repository not found: {url}")
                return {}
            
            if response.status_code == 403:
                data = response.json()
                if "API rate limit exceeded" in data.get("message", ""):
                    self.errors.append(
                        "GitHub API rate limit exceeded. "
                        "Use authentication for higher limits: "
                        "export GITHUB_TOKEN=<your_token>"
                    )
                else:
                    self.errors.append(f"Access forbidden: {data.get('message', 'Unknown error')}")
                return {}
            
            if response.status_code != 200:
                self.errors.append(f"API error {response.status_code}: {response.text[:200]}")
                return {}
            
            return response.json()
        except requests.exceptions.RequestException as e:
            self.errors.append(f"Request failed: {e}")
            return {}
    
    def _detect_main_branch(self) -> str:
        """Detect main branch by fetching repo details."""
        endpoint = f"/repos/{self.owner}/{self.repo}"
        data = self._api_request(endpoint)
        if data and "default_branch" in data:
            return data["default_branch"]
        
        # Fallback to common names
        for candidate in ["main", "master", "trunk", "develop"]:
            endpoint = f"/repos/{self.owner}/{self.repo}/branches/{candidate}"
            data = self._api_request(endpoint)
            if data and "name" in data:
                return candidate
        
        return "main"  # Default fallback
    
    def get_branches(self) -> List[Dict]:
        """Get all branches with metadata."""
        branches = []
        page = 1
        
        while True:
            endpoint = f"/repos/{self.owner}/{self.repo}/branches?per_page=100&page={page}"
            data = self._api_request(endpoint)
            
            if not isinstance(data, list):
                break
            
            if not data:
                break
            
            branches.extend(data)
            page += 1
        
        return branches
    
    def get_divergence(self, branch: str) -> Tuple[int, int]:
        """Get commits ahead and behind main using compare endpoint."""
        try:
            endpoint = f"/repos/{self.owner}/{self.repo}/compare/{self.main_branch}...{branch}"
            data = self._api_request(endpoint)
            
            if not data or "status" not in data:
                return 0, 0
            
            if data["status"] == "diverged":
                behind = data.get("behind_by", 0)
                ahead = data.get("ahead_by", 0)
                return ahead, behind
            elif data["status"] == "ahead":
                return data.get("ahead_by", 0), 0
            elif data["status"] == "behind":
                return 0, data.get("behind_by", 0)
            
            return 0, 0
        except:
            return 0, 0
    
    def classify_branch(self, days_old: int, ahead: int, behind: int, branch_name: str = "") -> str:
        """Classify branch health status."""
        # Identify main branch
        if branch_name == self.main_branch or (days_old == 0 and ahead == 0 and behind == 0 and branch_name):
            return "main"
        
        # Stale
        if days_old > 60:
            return "stale"
        
        # Diverged
        if behind > 60:
            return "diverged"
        
        # Monitor
        if days_old > 30 or behind > 30:
            return "monitor"
        
        # Healthy
        return "healthy"
    
    def analyze(self) -> Dict:
        """Run full analysis using GitHub API."""
        print("🔍 Fetching branches from GitHub...", file=sys.stderr)
        
        # Get all branches
        branch_data = self.get_branches()
        if not branch_data:
            return {"error": "No branches found or repository not accessible"}
        
        now = datetime.now()
        total = len(branch_data)
        active_count = 0
        stale_count = 0
        
        for idx, branch_info in enumerate(branch_data, 1):
            branch_name = branch_info["name"]
            print(f"  [{idx}/{total}] {branch_name}...", file=sys.stderr, end="\r")
            
            # Parse commit date
            commit_date_str = branch_info["commit"]["committed_date"]
            try:
                last_commit = datetime.fromisoformat(commit_date_str.replace("Z", "+00:00")).replace(tzinfo=None)
            except:
                last_commit = datetime.now()
            
            days_old = (now - last_commit).days
            ahead, behind = self.get_divergence(branch_name)
            status = self.classify_branch(days_old, ahead, behind, branch_name)
            
            self.branches[branch_name] = {
                "days_old": days_old,
                "last_commit": last_commit.isoformat(),
                "ahead": ahead,
                "behind": behind,
                "status": status,
            }
            
            if days_old <= 30:
                active_count += 1
            if days_old > 60:
                stale_count += 1
        
        print(" " * 80, file=sys.stderr, end="\r")  # Clear line
        
        # Calculate aggregate metrics
        active_ratio = (active_count / total * 100) if total > 0 else 0
        avg_staleness = sum(b["days_old"] for b in self.branches.values()) / total if total > 0 else 0
        avg_behind = sum(b["behind"] for b in self.branches.values()) / total if total > 0 else 0
        
        # Health score (0-10)
        health_score = 10.0
        if active_ratio < 50:
            health_score -= 3
        if stale_count > total * 0.2:
            health_score -= 2
        if any(b["behind"] > 60 for b in self.branches.values()):
            health_score -= 1
        
        return {
            "repository": f"{self.owner}/{self.repo}",
            "main_branch": self.main_branch,
            "total_branches": total,
            "active_branches": active_count,
            "stale_branches": stale_count,
            "active_ratio": round(active_ratio, 1),
            "avg_staleness_days": round(avg_staleness, 1),
            "avg_divergence_behind": round(avg_behind, 1),
            "health_score": round(max(0, health_score), 1),
            "branches": self.branches,
            "errors": self.errors,
            "timestamp": datetime.now().isoformat(),
        }

def format_report(data: Dict) -> str:
    """Format analysis results as human-readable report."""
    if "error" in data:
        return f"❌ Error: {data['error']}"
    
    lines = []
    lines.append("=" * 80)
    lines.append("TIER 1 BRANCH HEALTH REPORT")
    lines.append("=" * 80)
    lines.append("")
    
    # Repository info
    if "repository" in data:
        lines.append(f"📦 Repository: {data['repository']} (main: {data['main_branch']})")
        lines.append("")
    
    # Summary dashboard
    lines.append("📊 SUMMARY DASHBOARD")
    lines.append("-" * 80)
    lines.append(f"Total Branches:        {data['total_branches']}")
    lines.append(f"Active (last 30d):     {data['active_branches']} ({data['active_ratio']}%)")
    lines.append(f"Stale (>60d):          {data['stale_branches']}")
    lines.append(f"Avg Staleness:         {data['avg_staleness_days']} days")
    lines.append(f"Avg Divergence:        {data['avg_divergence_behind']} commits behind main")
    lines.append(f"Health Score:          {data['health_score']}/10")
    lines.append("")
    
    # Branch inventory
    lines.append("📋 BRANCH INVENTORY")
    lines.append("-" * 80)
    lines.append(f"{'Branch':<30} {'Age':<8} {'Behind':<8} {'Status':<12} {'Action'}")
    lines.append("-" * 80)
    
    # Sort branches by status priority
    status_order = {"healthy": 0, "monitor": 1, "diverged": 2, "stale": 3, "main": -1}
    sorted_branches = sorted(
        data['branches'].items(),
        key=lambda x: (status_order.get(x[1]['status'], 4), x[1]['days_old'])
    )
    
    for branch, info in sorted_branches:
        status = info['status'].upper()
        emoji = {
            "main": "✓",
            "healthy": "✓",
            "monitor": "⚠",
            "diverged": "✗",
            "stale": "✗",
        }.get(info['status'], "?")
        
        action = ""
        if info['status'] == "healthy" and info['days_old'] <= 7:
            action = "Merge soon"
        elif info['status'] == "monitor":
            action = "Rebase in 2w"
        elif info['status'] == "diverged":
            action = "High conflict risk"
        elif info['status'] == "stale":
            action = "Archive or decide"
        
        lines.append(
            f"{branch:<30} {info['days_old']:<8} {info['behind']:<8} "
            f"{emoji} {status:<10} {action}"
        )
    
    lines.append("")
    
    # Recommendations
    lines.append("💡 RECOMMENDATIONS")
    lines.append("-" * 80)
    
    stale = [b for b, info in data['branches'].items() if info['status'] == 'stale']
    diverged = [b for b, info in data['branches'].items() if info['status'] == 'diverged']
    monitor = [b for b, info in data['branches'].items() if info['status'] == 'monitor']
    
    if stale:
        lines.append(f"1. Archive {len(stale)} stale branch(es): {', '.join(stale[:3])}")
        if len(stale) > 3:
            lines.append(f"   ... and {len(stale) - 3} more")
    
    if diverged:
        lines.append(f"2. Review {len(diverged)} diverged branch(es) for conflicts: {', '.join(diverged[:3])}")
    
    if monitor:
        lines.append(f"3. Rebase/merge {len(monitor)} monitoring branch(es) within 2 weeks")
    
    healthy_ready = [
        b for b, info in data['branches'].items()
        if info['status'] == 'healthy' and info['days_old'] <= 7
    ]
    if healthy_ready:
        lines.append(f"4. Merge {len(healthy_ready)} ready-to-merge branch(es)")
    
    if data['active_ratio'] < 50:
        lines.append("⚠️  WARNING: Repository hygiene is poor. Consider scheduled cleanup.")
    
    lines.append("")
    lines.append("=" * 80)
    lines.append(f"Report generated: {data['timestamp']}")
    lines.append("=" * 80)
    
    return "\n".join(lines)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python analyze_branches.py <github_url> [--json]")
        print("Example: python analyze_branches.py https://github.com/owner/repo")
        print("         python analyze_branches.py git@github.com:owner/repo.git --json")
        sys.exit(1)
    
    repo_url = sys.argv[1]
    output_json = "--json" in sys.argv
    
    try:
        analyzer = GitHubBranchAnalyzer(repo_url)
        data = analyzer.analyze()
        
        if output_json:
            print(json.dumps(data, indent=2))
        else:
            print(format_report(data))
    
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)
